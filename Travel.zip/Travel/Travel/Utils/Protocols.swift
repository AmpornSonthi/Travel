////
////  File.swift
////  Travel
////
////  Created by AOM on 8/18/20.
////  Copyright © 2020 AOM. All rights reserved.
////
//

import UIKit

protocol CommentInputAccesoryViewDelegate {
    func didSubmit(forComment comment: String, refreshControll: UIRefreshControl)
    
}
 
protocol ProfileHeadCellDelegate {
    func handleEditFollowTapped(for header:ProfileHeadCell)
    func setUserStats(for header:ProfileHeadCell)
}
