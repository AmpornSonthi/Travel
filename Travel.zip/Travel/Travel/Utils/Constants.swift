//
//  Constants.swift
//  Travel
//
//  Created by AOM on 7/14/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import Firebase

// MARK: - Root References
let DB_REF = Firestore.firestore()
let STORAGE_REF = Storage.storage().reference()

// MARK: - Database References
let COLLECTION_USER = DB_REF.collection("users")
// post
let COLLECTION_POST = DB_REF.collection("posts")
let COLLECTION_USER_POST = DB_REF.collection("user-posts")
let COLLECTION_HASHTAG_POST = DB_REF.collection("hashtag-post")
// follow
let COLLECTION_USER_FOLLOWER = DB_REF.collection("user-followers")
let COLLECTION_USER_FOLLOWING = DB_REF.collection("user-following")
// feed
let COLLECTION_USER_FEED = DB_REF.collection("user-feed")
// likes
let COLLECTION_USER_LIKE = DB_REF.collection("user-likes")
let COLLECTION_POST_LIKE = DB_REF.collection("post-likes")
// notification
let COLLECTION_NOTIFICATIONS = DB_REF.collection("notifications")
// comments
let COLLECTION_COMMENT = DB_REF.collection("comments")
let COLLECTION_GENID = DB_REF.collection("comments-id")
// message
let COLLECTION_MESSAGES = DB_REF.collection("messages")
let COLLECTION_USER_MESSAGES = DB_REF.collection("user-messages")
let COLLECTION_NOTIFICATIONS_REF = DB_REF.collection("user-message-notifications")

// MARK: - Storage References
let STORAGE_PROFILE_IMAGES_REF = STORAGE_REF.child("profile_images")
let STORAGE_MESSAGE_IMAGES_REF = STORAGE_REF.child("message_images")
let STORAGE_MESSAGE_VIDEO_REF = STORAGE_REF.child("video_messages")
let STORAGE_POST_IMAGES_REF = STORAGE_REF.child("post_images")

// MARK: - Key
//let POSTKEY = ["postKey":1]

 // MARK: - Decoding Values

let LIKE_INT_VALUE = 0
let COMMENT_INT_VALUE = 1
let FOLLOW_INT_VALUE = 2
let COMMENT_MENTION_INT_VALUE = 3
let POST_MENTION_INT_VALUE = 4

// MARK: - Message
let MSG_RESET_PASSWORD = "We sent a link to your email to reset your password."
