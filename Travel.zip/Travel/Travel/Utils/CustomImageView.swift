//
//  CustomImageView.swift
//  Travel
//
//  Created by AOM on 7/16/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

var imageCache = [String:UIImage]()

class CustomImageView: UIImageView {
    
    // MARK: - Lifecycle
    
    init(bgColor:UIColor = .lightGray) {
        super.init(frame:.zero)
        
        contentMode = .scaleAspectFill
        clipsToBounds = true
        backgroundColor = .lightGray
       
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func loadImage(with urlString:String) {
        
        var lastImgUrlUsed:String?
        
        // set image to nil
        self.image = nil
        
        lastImgUrlUsed = urlString
        
        // check if image exists in cache
        if let cachedImage = imageCache[urlString] {
            self.image = cachedImage
            return
        }
        
        // url for image location
        guard let url = URL(string: urlString) else { return }
        
        // fetch contents of URL
        URLSession.shared.dataTask(with: url) {(data,response,error) in
            
            if let error = error {
                print("debug failed to load image with error" ,error.localizedDescription)
            }
            
            if  lastImgUrlUsed != url.absoluteString {
                print("of block exectued")
                return
            }
            
            // image data
            guard let imageData = data else { return }
            
            // create image using image data
            let photoImage = UIImage(data: imageData)
            
            // set key and value for image cache
            imageCache[url.absoluteString] = photoImage
            
            // set image
            DispatchQueue.main.async {
                self.image = photoImage
            }
        }.resume()
    }
    
}
