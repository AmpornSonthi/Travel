//
//  MessageCell.swift
//  Travel
//
//  Created by AOM on 7/18/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit
import Firebase

protocol MessageCellDelegate {
    func configureUserData(for cell: ConversationCell)
}

class ConversationCell: UITableViewCell {
    
    // MARK: - Properties
    
    var delegate: MessageCellDelegate?
    
    var conversation:Conversation? {
        didSet { configure() }
    }
    
    
    let profileImageView:CustomImageView = {
        let iv = CustomImageView()
        iv.setDimensions(height: 65, width: 65)
        iv.layer.cornerRadius = 65 / 2
        return iv
    }()
    
    let usernameLabel:CustomTitleLabel = {
        let label = CustomTitleLabel(attributedTitle: "usernameLabel",fontSize: 20)
        label.textAlignment = .left
        label.textColor = #colorLiteral(red: 0.4254474342, green: 0.6391789317, blue: 0.7850681543, alpha: 1)
        return label
    }()
    
    let messageLabel:CustomTitleLabel = {
        let label = CustomTitleLabel(attributedTitle: "usernameLabel",fontSize: 18)
        label.textAlignment = .left
        label.textColor = .lightGray
        return label
    }()
    
    let timestampLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 12)
        label.textColor = .darkGray
        label.text = "2h"
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style:style,reuseIdentifier:reuseIdentifier)
        
        selectionStyle = .none
        
        addSubview(profileImageView)
        profileImageView.anchor(top: safeAreaLayoutGuide.topAnchor, left: leftAnchor,  paddingTop: 40, paddingLeft: 15, paddingBottom: 10, paddingRight: 10)
        
        let stack = UIStackView(arrangedSubviews: [usernameLabel,messageLabel])
        stack.axis = .vertical
        stack.distribution = .fillProportionally
        stack.spacing = 3
        
        addSubview(stack)
        stack.anchor(left: profileImageView.rightAnchor, paddingLeft:8)
        stack.centerYAnchor.constraint(equalTo: profileImageView.centerYAnchor).isActive = true
        
        addSubview(timestampLabel)
        timestampLabel.anchor(right:rightAnchor, paddingRight:15)
        timestampLabel.centerYAnchor.constraint(equalTo: profileImageView.centerYAnchor).isActive = true
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Handlers
    
    func configure() {
        
       guard let conversations = conversation else { return }
        let viewModel = ConversationViewModel(conversation: conversations)
        usernameLabel.text = conversations.user.username
        messageLabel.text = conversations.message.text
        
        timestampLabel.text = viewModel.timestamp
        profileImageView.sd_setImage(with: viewModel.profileImageUrl)
        
    }
    
    func configureTimestamp(forMessage message: Message) {
        //        if let seconds = message.creationDate {
        //            let dateFormatter = DateFormatter()
        //            dateFormatter.dateFormat = "hh:mm a"
        //            timestampLabel.text = dateFormatter.string(from: seconds)
        //        }
    }
    
}
