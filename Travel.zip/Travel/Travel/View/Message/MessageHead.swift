//
//  MessageHead.swift
//  Travel
//
//  Created by AOM on 7/18/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

private let cellIdentifier = "MessageHead"

protocol MessageHeaderDelegate:class {
    func messageHeader(_ header:MessageHead,wantToStartChartWith uid:String)
}

class MessageHead: UICollectionReusableView {
    
    // MARK: - Properties
    
    weak var delegate:MessageHeaderDelegate?
    
    private lazy var headLabel:CustomTitleLabel = {
        let label = CustomTitleLabel(attributedTitle:"All Friends")
        label.textColor = .black
        return label
    }()
    
    private lazy var footerLabel:CustomTitleLabel = {
        let label = CustomTitleLabel(attributedTitle:"Recent Conversations",fontSize: 16)
        label.textColor = .lightGray
        return label
    }()
    
    private lazy var collectionView:UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.backgroundColor = .white
        cv.delegate = self
        cv.dataSource = self
        cv.register(MessageHeadCell.self, forCellWithReuseIdentifier: cellIdentifier)
        return cv
    }()
    
    // MARK: - Lifecycle
    
    override init(frame: CGRect) {
        super.init(frame:frame)
        
        backgroundColor = .white
        
        addSubview(headLabel)
        headLabel.anchor(top: topAnchor, left: leftAnchor, paddingTop: 15, paddingLeft: 15)
        
        addSubview(collectionView)
        collectionView.anchor(top: headLabel.bottomAnchor, left: leftAnchor, bottom: bottomAnchor, right: rightAnchor, paddingTop: 4, paddingLeft: 18, paddingRight: 12)
        
        addSubview(footerLabel)
        footerLabel.anchor(top: collectionView.bottomAnchor, left: leftAnchor, paddingTop: 5, paddingLeft: 12)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Handlers
    
    // MARK: - API
}


extension MessageHead:UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath) as! MessageHeadCell
        
        return cell
    }
    
}

extension MessageHead:UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
    }
}

extension MessageHead:UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: 88, height: 124)
    }
}
