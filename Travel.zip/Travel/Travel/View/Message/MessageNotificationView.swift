//
//  MessageNotificationView.swift
//  Travel
//
//  Created by AOM on 8/3/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

class MessageNotificationView: UIView {

    var notificationLabel:CustomTitleLabel = {
        let label = CustomTitleLabel(attributedTitle: "message")
        label.textColor = .black
        return label
        
    }()
    
    override init(frame: CGRect) {
        super.init(frame:frame)
        
        backgroundColor = .red
        
        addSubview(notificationLabel)
        notificationLabel.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        notificationLabel.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
