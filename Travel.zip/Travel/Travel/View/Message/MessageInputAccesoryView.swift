//
//  MessageInputAccesoryView.swift
//  Travel
//
//  Created by AOM on 8/10/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

protocol MessageInputAccesoryViewDelegate:class {
    func inputView(_ inputView: MessageInputAccesoryView,wantsToSend message:String)
}

class MessageInputAccesoryView: UIView {
    
    // MARK: - Properties
    
   weak var delegate: MessageInputAccesoryViewDelegate?
    
   private lazy var messageTextView: InputTextView = {
        let tv = InputTextView()
        tv.font = UIFont(name: "Marker Felt", size: 16)
        tv.isScrollEnabled = false
        return tv
    }()
    
    private lazy var sendButton:CustomTitleButton = {
        let button = CustomTitleButton(attributedTitle: "Send")
        button.tintColor = #colorLiteral(red: 0.9294117647, green: 0.5294117647, blue: 0.4745098039, alpha: 1)
        button.addTarget(self, action: #selector(handleSendMessage), for: .touchUpInside)
        return button
    }()
    
    // MARK: - Init
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        autoresizingMask = .flexibleHeight
        layer.shadowOpacity = 0.25
        layer.shadowRadius = 10
        layer.shadowOffset = .init(width: 0, height: -8)
        layer.shadowColor = UIColor.lightGray.cgColor
        
        backgroundColor = .white
        
        addSubview(messageTextView)
        messageTextView.anchor(top: topAnchor, left: leftAnchor, bottom: safeAreaLayoutGuide.bottomAnchor, right: nil, paddingTop: 8, paddingLeft: 8, paddingBottom: 0, paddingRight: 16,width: frame.width)
        
        let separatorView = UIView()
        separatorView.backgroundColor = UIColor(red: 230/255, green: 230/255, blue: 230/255, alpha: 1)
        addSubview(separatorView)
        separatorView.anchor(top: topAnchor, left: leftAnchor, bottom: nil, right: rightAnchor, paddingTop: 0, paddingLeft: 0, paddingBottom: 0, paddingRight: 0, width: 0, height: 0.5)
        
        addSubview(sendButton)
        sendButton.anchor(top: topAnchor, left: nil, bottom: nil, right: rightAnchor, paddingTop: 0, paddingLeft: 0, paddingBottom: 0, paddingRight: 8)
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleTextInputChange), name: UITextView.textDidChangeNotification, object: nil)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func handleTextInputChange() {
        
    }
    
    override var intrinsicContentSize: CGSize {
        return .zero
    }
    
    // MARK: - Helpers
    
    func clearMessageTextView() {
        messageTextView.placeholderLabel.isHidden = false
        messageTextView.text = nil
        
    }
    
    // MARK: - Handlers
    
    @objc func handleSendMessage() {
        print("handleSendMessage")
        guard let message = messageTextView.text else { return }
        
        delegate?.inputView(self, wantsToSend: message)
    }
}
