//
//  MessageCell.swift
//  Travel
//
//  Created by AOM on 7/18/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

class MessageHeadCell: UICollectionViewCell {
    
    // MARK: - Properties
    
    private let profileImageView:CustomImageView = {
        let iv = CustomImageView()
        iv.setDimensions(height: 90, width: 90)
        iv.layer.cornerRadius = 90 / 2
        return iv
    }()
    
    private let usernameLabel:CustomTitleLabel = {
        let label = CustomTitleLabel(attributedTitle: "username",fontSize: 16)
        label.textAlignment = .center
         label.textColor = .systemPink
        return label
    }()
    
    // MARK: - Lifecycle
    
    override init(frame: CGRect) {
        super.init(frame:frame)
        
        let stack = UIStackView(arrangedSubviews: [profileImageView,usernameLabel])
        stack.axis = .vertical
        stack.distribution = .fillProportionally
//        stack.spacing = 0
        
        addSubview(stack)
        stack.fillSuperview()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
     // MARK: - Handlers
     
     // MARK: - API
    
}
