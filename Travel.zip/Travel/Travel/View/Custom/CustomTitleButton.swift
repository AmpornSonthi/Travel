//
//  CustomTitleButton.swift
//  Travel
//
//  Created by AOM on 7/13/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

class CustomTitleButton: UIButton {

    init(attributed:String = "",attributedTitle:String = "") {
        super.init(frame:.zero)
        
        let attributedText = NSMutableAttributedString(string: "\(attributedTitle)",attributes: [NSAttributedString.Key.font:UIFont(name: "Marker Felt", size: 17) ?? "System"])

        attributedText.append(NSAttributedString(string: "\(attributed)",attributes: [NSAttributedString.Key.font:UIFont(name: "Marker Felt", size: 20) ?? "System" ,NSAttributedString.Key.foregroundColor:UIColor.white]))
        
        setAttributedTitle(attributedText, for: .normal)
       
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
