//
//  NavigationButton.swift
//  Travel
//
//  Created by AOM on 7/13/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

class NavigationButton: UIButton {
    
    override init(frame: CGRect) {
        super.init(frame:frame)

        tintColor = .white
        let attributedText = NSMutableAttributedString(string: "Back",attributes: [NSAttributedString.Key.font:UIFont(name: "Marker Felt", size: 17) ?? "System"])

        setAttributedTitle(attributedText, for: .normal)
        setImage(#imageLiteral(resourceName: "ic_back_white").withRenderingMode(.alwaysOriginal), for: .normal)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
