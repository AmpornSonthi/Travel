//
//  CustomTitleLabel.swift
//  Travel
//
//  Created by AOM on 7/12/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

class CustomTitleLabel: UILabel {
    
    init(attributedTitle:String,fontSize:CGFloat = 20,attributed:String = "",numberOfLine:Int = 1) {
        
        super.init(frame:.zero)
        
        let attributedText = NSMutableAttributedString(string: "\(attributedTitle)\n", attributes: [NSAttributedString.Key.font: UIFont(name: "Marker Felt", size: fontSize) ?? "Marker Felt"])
        
        attributedText.append(NSAttributedString(string:attributed, attributes: [NSAttributedString.Key.font: UIFont(name: "Marker Felt", size: 20) ?? "Marker Felt", NSAttributedString.Key.foregroundColor: UIColor.white]))
        
        
        self.attributedText = attributedText
        numberOfLines = numberOfLine
        textAlignment = .center
        textColor = .white
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
