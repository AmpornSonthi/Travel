//
//  UIImage.swift
//  Travel
//
//  Created by AOM on 7/14/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

extension UIImage {  
    static func setImages(_ name: String, template: Bool = false) -> UIImage {
        var image = UIImage(named: name)!
        if template {
            image = image.withRenderingMode(.alwaysTemplate)
        }
        return image
    }
}
