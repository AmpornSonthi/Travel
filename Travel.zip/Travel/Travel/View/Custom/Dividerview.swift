//
//  Dividerview.swift
//  Travel
//
//  Created by AOM on 7/11/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

class Dividerview: UIView {
    
    // MARK: - Lifecycle
    
    override init(frame: CGRect) { 
        super.init(frame:frame)
        
        let lable = UILabel()
        lable.textColor = UIColor(white: 1, alpha: 0.9)
        lable.attributedText = NSMutableAttributedString(string: "Or Sign Up With...", attributes: [NSAttributedString.Key.font: UIFont(name: "Marker Felt", size: 14) ?? "System"])
        
        
        addSubview(lable)
        lable.centerX(inView: self)
        lable.centerY(inView: self)
        
        let divider1 = UIView()
        divider1.backgroundColor = UIColor(white: 1, alpha: 0.25)
        addSubview(divider1)
        divider1.centerY(inView: self)
        divider1.anchor(left:leftAnchor,right: lable.leftAnchor,
                        paddingLeft: 8,paddingRight: 8,height: 1.0)
        
        let divider2 = UIView()
        divider2.backgroundColor = UIColor(white: 1, alpha: 0.25)
        addSubview(divider2)
        divider2.centerY(inView: self)
        divider2.anchor(left:lable.rightAnchor,right: rightAnchor,
                        paddingLeft: 8,paddingRight: 8,height: 1.0)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
