//
//  CustomTextField.swift
//  Travel
//
//  Created by AOM on 7/11/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit
import Foundation

class CustomTextField: UITextField {

    // MARK: - Lifecycle
    
    init(placeholder:String = "" ,image: UIImage? = nil ,isSecureField:Bool? = false) {
        super.init(frame:.zero)
        
        let iconView = UIImageView(frame: CGRect(x: 15, y: 3, width: 25, height: 25))
           iconView.image = image
           let iconContainerView: UIView = UIView(frame:CGRect(x: 40, y: 0, width: 50, height: 30))
        iconContainerView.addSubview(iconView)
           leftView = iconContainerView
           leftViewMode = .always
        
        borderStyle = .none
        textColor = .white
        layer.borderColor = UIColor.clear.cgColor
        layer.borderWidth = 15
        keyboardAppearance = .light
        backgroundColor = UIColor(white: 1, alpha: 0.1)
        font = UIFont(name: "Marker Felt", size: 18)!
        setHeight(height: 50)
        
        attributedPlaceholder = NSAttributedString(string:placeholder,attributes: [NSAttributedString.Key.font:UIFont(name: "Marker Felt", size: 18) ?? "System"])
         isSecureTextEntry = isSecureField!
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
