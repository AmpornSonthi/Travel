//
//  AutnButton.swift
//  Travel
//
//  Created by AOM on 7/11/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

class AuthButton: UIButton {
    
    //  MARK: - Properties
    
    var title:String? {
        didSet {
            setTitle(title, for: .normal)
            titleLabel?.font = UIFont(name: "Marker Felt", size: 25)!
            imageView?.contentMode = .scaleAspectFit
        }
    }
    
    // MARK: - Lifecycle
    
    override init(frame:CGRect) {
        super.init(frame:frame)
        
        setTitleColor(UIColor(white: 1, alpha: 1), for: .normal)
        layer.cornerRadius = 25
        layer.borderColor = UIColor.clear.cgColor
        layer.borderWidth = 5
        isEnabled = true
    
        heightAnchor.constraint(equalToConstant: 60).isActive = true
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
