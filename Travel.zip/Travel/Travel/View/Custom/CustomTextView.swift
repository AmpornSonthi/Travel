//
//  CustomTextView.swift
//  Travel
//
//  Created by AOM on 7/24/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

extension UITextView{

    func setPlaceholder() {

        let placeholderLabel = UILabel()
        placeholderLabel.text = "Write a caption..."
        placeholderLabel.font = UIFont(name: "Marker Felt", size: 16)!
        placeholderLabel.sizeToFit()
        placeholderLabel.tag = 222
        placeholderLabel.frame.origin = CGPoint(x: 5, y: (self.font?.pointSize)! / 2)
        placeholderLabel.textColor = UIColor.lightGray
        placeholderLabel.isHidden = !self.text.isEmpty
        
       font = UIFont(name: "Marker Felt", size: 16)!

        self.addSubview(placeholderLabel)
    }

    func checkPlaceholder() {
        let placeholderLabel = self.viewWithTag(222) as! UILabel
        placeholderLabel.isHidden = !self.text.isEmpty
    }

}
