//
//  ProfileHeadCell.swift
//  Travel
//
//  Created by AOM on 7/19/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit
import Firebase


class ProfileHeadCell: UICollectionViewCell {
    
    // MARK: - Properties
    
    var delegate:ProfileHeadCellDelegate?
    
    var user:User? {
        
        didSet {
            
            // configure edit profile button
            configureEditProfileFollowBtn()
            
            // set user stats
            setUserStats(for: user)
            
            let fullname = self.user?.username
            self.nameLabel.text = fullname
            
            guard let profileImageUrl = user?.profileImageUrl else { return }
            
            profileImageView.loadImage(with: profileImageUrl)
            
        }
    }
    
    let profileImageView:CustomImageView = {
        let iv = CustomImageView()
        iv.layer.borderColor = UIColor.white.cgColor
        iv.layer.borderWidth = 3
        iv.layer.cornerRadius = 5
        return iv
    }()
    
    lazy var nameLabel:CustomTitleLabel = {
        let label = CustomTitleLabel(attributedTitle: "",fontSize: 30)
        return label
    }()
    
    lazy var addressLabel:CustomTitleLabel = {
        let label = CustomTitleLabel(attributedTitle: "")
        return label
    }()
    
    let postLabel:CustomTitleLabel = {
        
        let label = CustomTitleLabel(attributedTitle: "0", fontSize: 20, attributed: "post", numberOfLine: 2)
        label.textAlignment = .center
        label.numberOfLines = 0
        
        return label
    }()
    
    lazy var followersLabel:UILabel = {
        let label = CustomTitleLabel(attributedTitle: "0", fontSize: 20, attributed: "followers", numberOfLine: 2)
        label.textAlignment = .center
        label.numberOfLines = 0
        
        return label
    }()
    
    lazy var followingLabel:CustomTitleLabel = {
        let label = CustomTitleLabel(attributedTitle: "0", fontSize: 20, attributed: "following", numberOfLine: 2)
        label.textAlignment = .center
        label.numberOfLines = 0
        
        
        return label
    }()
    
    lazy var editProfileButton:UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Loading", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.addTarget(self, action: #selector(handleEditProfileFollow), for: .touchUpInside)
        return button
    }()
    
    override init(frame: CGRect) {
        super.init(frame: .zero)
        
        backgroundColor = #colorLiteral(red: 0.9568627451, green: 0.7215686275, blue: 0.6941176471, alpha: 1)
        
        configureStatus()
    }
    
    func configureStatus()  {
        
        addSubview(editProfileButton)
        editProfileButton.anchor(top:topAnchor, right: rightAnchor, paddingTop: 40,paddingRight: 20)
        
        addSubview(profileImageView)
        profileImageView.anchor(top: editProfileButton.bottomAnchor,left: leftAnchor,paddingTop: 20, paddingLeft: 40,width:100, height: 120)
        
        let stackView = UIStackView(arrangedSubviews: [nameLabel,addressLabel])
        stackView.axis = .vertical
        stackView.spacing = 5
        
        addSubview(stackView)
        stackView.anchor( left:leftAnchor, paddingLeft: 150)
        stackView.centerYAnchor.constraint(equalTo: profileImageView.centerYAnchor).isActive = true
        
        let stackViewBtn = UIStackView(arrangedSubviews: [followersLabel,followingLabel,postLabel])
        stackViewBtn.axis = .horizontal
        stackViewBtn.spacing = 15
        
        addSubview(stackViewBtn)
        stackViewBtn.anchor(top: nil, left: leftAnchor, bottom: safeAreaLayoutGuide.bottomAnchor, right: rightAnchor, paddingTop: 40, paddingLeft: 12, paddingBottom: 15, paddingRight: 12)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Handlers
    
    @objc func handleEditProfileFollow() {
        delegate?.handleEditFollowTapped(for: self)
    }
    
    func setUserStats(for user:User?) {
        delegate?.setUserStats(for: self)
    }
    
    func configureEditProfileFollowBtn()  {
        
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        guard let user  = self.user else {return}
        
        print("configureEditProfileFollowBtn currentUid \(currentUid)")
        print("configureEditProfileFollowBtn uid \(user.uid)")
        
        print("configureEditProfileFollowBtn isFollowed \(user.isFollowed)")
        
        if currentUid == user.uid {
            
            // configure button as edit profile
            editProfileButton.setTitle("...", for: .normal)
             editProfileButton.setTitleColor(.white, for: .normal)
            editProfileButton.titleLabel?.font = UIFont(name: "Marker Felt", size: 30)!
            
        } else {
            // configure button as follow button
            editProfileButton.titleLabel?.font = UIFont(name: "Marker Felt", size: 20)!
            
            if COLLECTION_USER_FOLLOWING.document(currentUid) == nil {
                 COLLECTION_USER_FOLLOWING.addDocument(data: [currentUid : 1])
            }
            
            user.checkIfUserIsFollowed(completion: {(followed) in
                
                print("configureEditProfileFollowBtn else \(followed)")
                
                if followed {
                    self.editProfileButton.setTitle("Following", for: .normal)
                }else {
                    self.editProfileButton.setTitle("Follow", for: .normal)
                }
            })
        }
        
    }
    
}
