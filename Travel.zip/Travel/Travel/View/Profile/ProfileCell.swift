//
//  ProfileCell.swift
//  Travel
//
//  Created by AOM on 7/19/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

class ProfileCell: UICollectionViewCell {
    
    var post: Post? {
         
         didSet {
             guard let imageUrl = post?.imageUrl else { return }
             
             print("img ", imageUrl)
             postImageView.loadImage(with: imageUrl)
         }
     }
    
    let postImageView: CustomImageView = {
           let iv = CustomImageView()
           iv.contentMode = .scaleAspectFill
           iv.clipsToBounds = true
           return iv
       }()
       
       override init(frame: CGRect) {
           super.init(frame: frame)
        
        backgroundColor = .yellow
           
           addSubview(postImageView)
           postImageView.anchor(top: safeAreaLayoutGuide.topAnchor, left: leftAnchor, bottom: bottomAnchor, right: rightAnchor, paddingTop: 0, paddingLeft: 0, paddingBottom: 0, paddingRight: 0)
       }
       
       required init?(coder aDecoder: NSCoder) {
           fatalError("init(coder:) has not been implemented")
       }
    
}
