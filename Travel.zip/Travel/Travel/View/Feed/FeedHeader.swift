//
//  FeedHeader.swift
//  Travel
//
//  Created by AOM on 7/18/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

class FeedHeader: UICollectionReusableView {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
