//
//  FeedCell.swift
//  Travel
//
//  Created by AOM on 7/16/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit
import ActiveLabel

protocol FeedCellDelegate {
    func handleUsernameTapped(for cell: FeedCell)
    func handleConfigureLikeButton(for cell: FeedCell)
    func handleLikeTapped(for cell: FeedCell, isDoubleTap: Bool)
    func handleCommentTapped(for cell: FeedCell)
    func configureCommentIndicatorView(for cell: FeedCell)
}

class FeedCell: UICollectionViewCell {
    
    var delegate:FeedCellDelegate?
    var stackView: UIStackView!
    
    var posts:Post? {
        didSet {
            guard let ownerUid = posts?.ownerUid else { return }
            guard let imageUrl = posts?.imageUrl else { return }
            guard let likes = posts?.likes else { return }
            
            FetchDatabase.fetchUserWithUid(with: ownerUid) { (user) in
                self.profileImageView.loadImage(with: user.profileImageUrl)
                self.usernameButton.setTitle(user.username, for: .normal)
                self.configurePostCaption(user: user)
            }
            postImageView.loadImage(with: imageUrl)
            likesLabel.text = "\(likes)"
            configureLikeButton()
            configureCommentIndicatorView()
        }
    }
    
    private let profileImageView = CustomImageView()
    
    lazy var usernameButton:UIButton = {
        let button = UIButton(type: .system)
        button.tintColor = .black
        button.addTarget(self, action: #selector(handleUsernameTapped), for: .touchUpInside)
        return button
    }()
    
    private let postImageView:CustomImageView = {
        var iv = CustomImageView()
        iv.layer.cornerRadius = 10
        iv.clipsToBounds = true
        iv.contentMode = .scaleAspectFill
        
        let likeTap = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTapToLike))
        likeTap.numberOfTapsRequired = 2
        iv.isUserInteractionEnabled = true
        iv.addGestureRecognizer(likeTap)
        return iv
    }()
    
    lazy var likeButton: CustomTitleButton = {
        let button = CustomTitleButton()
        button.setImage(#imageLiteral(resourceName: "like_unselected"), for: .normal)
        button.tintColor = .black
        button.addTarget(self, action: #selector(handleLikeTapped) , for: .touchUpInside)
        return button
    }()
    
    lazy var commentButton: CustomTitleButton = {
        let button = CustomTitleButton()
        button.setImage(#imageLiteral(resourceName: "comment"), for: .normal)
        button.tintColor = .black
        button.addTarget(self, action: #selector(handleCommentTapped) , for: .touchUpInside)
        return button
    }()
    
    lazy var likesLabel:CustomTitleLabel = {
        let label = CustomTitleLabel(attributedTitle: "",fontSize: 16)
        label.textColor = .lightGray
        label.textAlignment = .left
        return label
    }()
    
    lazy var captionLabel: ActiveLabel = {
        let label = ActiveLabel()
        label.numberOfLines = 0
        label.hashtagColor = #colorLiteral(red: 0.8155518174, green: 0.5029943585, blue: 0.4398008883, alpha: 1)
        label.mentionColor = #colorLiteral(red: 0.9294117647, green: 0.5294117647, blue: 0.4745098039, alpha: 1)
        label.textAlignment = .left
        return label
    }()
    
    lazy var postTimeLabel:CustomTitleLabel = {
        let label = CustomTitleLabel(attributedTitle: "",fontSize: 16)
        label.textColor = .lightGray
        label.textAlignment = .left
        return label
    }()
    
    let commentIndicatorView: UIView = {
        let view = UIView()
        view.backgroundColor = #colorLiteral(red: 0.8155518174, green: 0.5029943585, blue: 0.4398008883, alpha: 1)
        return view
    }()
    
    override init(frame:CGRect) {
        super.init(frame:frame)
        
        backgroundColor = .white
        
        addSubview(profileImageView)
        profileImageView.anchor(top: topAnchor, left: leftAnchor, bottom: nil, right: nil, paddingTop: 20, paddingLeft: 8, paddingBottom: 0, paddingRight: 0, width: 40, height: 40)
        profileImageView.layer.cornerRadius = 40 / 2
        
        addSubview(usernameButton)
        usernameButton.anchor(top: nil, left: profileImageView.rightAnchor, bottom: nil, right: nil, paddingTop: 0, paddingLeft: 5, paddingBottom: 0, paddingRight: 0,  height: 20)
        usernameButton.centerYAnchor.constraint(equalTo: profileImageView.centerYAnchor).isActive = true
        
        configureActionButtons()
        
        let stackViewText = UIStackView(arrangedSubviews: [captionLabel,postTimeLabel])
        stackViewText.axis = .vertical
        stackViewText.spacing = 5
        
        addSubview(stackViewText)
        stackViewText.anchor(top: usernameButton.bottomAnchor, left: profileImageView.rightAnchor, bottom: nil, right: nil, paddingTop: 10, paddingLeft:8, paddingBottom: 0, paddingRight: 0, width: nil, height: nil)
        
        addSubview(postImageView)
        postImageView.anchor(top: stackViewText.bottomAnchor, left: profileImageView.rightAnchor,  right: rightAnchor, paddingTop: 16, paddingLeft: 0, paddingBottom: 5, paddingRight: -10, width: nil, height: 180)
        
    }
    
    // MARK: - Handlers
    
    @objc func handleUsernameTapped() {
        delegate?.handleUsernameTapped(for: self)
    }
    
    @objc func handleLikeTapped() {
        delegate?.handleLikeTapped(for: self, isDoubleTap: false)
    }
    
    @objc func handleCommentTapped() {
        delegate?.handleCommentTapped(for: self)
    }
    
    @objc func handleDoubleTapToLike() {
        delegate?.handleLikeTapped(for: self, isDoubleTap: true)
    }
    
    func configureCommentIndicatorView() {
        delegate?.configureCommentIndicatorView(for: self)
    }
    
    func configurePostCaption(user: User) {
        
        guard let post = self.posts else { return }
        guard let caption = post.caption else { return }
        //        guard let username = post.user?.username else { return }
        
        // look for username as pattern
        //        let customType = ActiveType.custom(pattern: "^\(username)\\b")
        
        // enable username as custom type
        captionLabel.enabledTypes = [.mention, .hashtag, .url]
        
        // configure usnerame link attributes
        captionLabel.configureLinkAttribute = { (type, attributes, isSelected) in
            
            var atts = attributes
            
            switch type {
            case .custom:
                atts[NSAttributedString.Key.font] = UIFont(name: "Marker Felt", size: 12) ?? "System"
            default: ()
            }
            return atts
        }
        
        captionLabel.customize { (label) in
            label.text = " \(caption)"
            //            label.customColor[customType] = .black
            label.font = UIFont.systemFont(ofSize: 12)
            label.textColor = .black
            captionLabel.numberOfLines = 2
        }
        
        postTimeLabel.text = post.creationDate.timeAgoToDisplay()
    }
    
    func configureActionButtons() {
        
        stackView = UIStackView(arrangedSubviews: [commentButton,likeButton, likesLabel])
        stackView.axis = .horizontal
        stackView.spacing = 10
        
        addSubview(stackView)
        stackView.anchor(top: nil, left: nil, bottom: nil, right: rightAnchor, paddingTop: 0, paddingLeft: 0, paddingBottom: 20, paddingRight: 15, height: 50)
        stackView.centerYAnchor.constraint(equalTo: profileImageView.centerYAnchor).isActive = true
    }
    
    func addCommentIndicatorView(toStackView stackView: UIStackView) {
        
        commentIndicatorView.isHidden = false
        
        stackView.addSubview(commentIndicatorView)
        commentIndicatorView.anchor(top: stackView.topAnchor, left: stackView.leftAnchor, bottom: nil, right: nil, paddingTop: 12, paddingLeft: 15, paddingBottom: 0, paddingRight: 0, width: 10, height: 10)
        commentIndicatorView.layer.cornerRadius = 10 / 2
    }
    
    func configureLikeButton() {
          delegate?.handleConfigureLikeButton(for: self)
      }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
