//
//  SearchUserCell.swift
//  Travel
//
//  Created by AOM on 7/20/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit
import SDWebImage

class UserCell: UITableViewCell {
    
    // MARK: - Properties
    
    var viewModel:UserViewModel! {
        didSet {
            usernameLabel.text = viewModel.username
            emailLabel.text = viewModel.email
            
            guard let url = URL(string:viewModel.profileImageUrl) else { return }
            
            profileImageView.sd_setImage(with:url)
            
            print("usersss \(viewModel.username) \(viewModel.profileImageUrl)")
        }
    }
    
    let profileImageView:CustomImageView = {
        let iv = CustomImageView()
        
        return iv
    }()
    
    lazy var usernameLabel:CustomTitleLabel = {
        let label = CustomTitleLabel(attributedTitle: "Username")
        label.textColor = .black
        label.textAlignment = .left
        return label
    }()
    
    lazy var emailLabel:CustomTitleLabel = {
        let label = CustomTitleLabel(attributedTitle: "Email",fontSize:16 )
        label.textColor = .lightGray
        label.textAlignment = .left
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .subtitle, reuseIdentifier: reuseIdentifier)
        
        addSubview(profileImageView)
        profileImageView.anchor(top: topAnchor, left: leftAnchor, bottom: nil, right: nil, paddingTop: 10, paddingLeft: 15, paddingBottom: 10, paddingRight: 0, width: 50, height: 50)
        profileImageView.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        profileImageView.layer.cornerRadius = 50 / 2
        profileImageView.clipsToBounds = true
        
        let stack = UIStackView(arrangedSubviews: [usernameLabel,emailLabel])
        stack.axis = .vertical
        stack.spacing = 5
        //
        addSubview(stack)
        stack.anchor(left: profileImageView.rightAnchor,paddingLeft:15)
        stack.centerYAnchor.constraint(equalTo: profileImageView.centerYAnchor).isActive = true
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
