 //
 //  MessageViewModel.swift
 //  Travel
 //
 //  Created by AOM on 8/10/20.
 //  Copyright © 2020 AOM. All rights reserved.
 //
 
 import Foundation
 import UIKit
 
 struct ChatViewModel {
    
    private let message:Message
    
    var messageBackgroundColor:UIColor{
        return message.isFromCurrentUser ? #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1) : #colorLiteral(red: 0.9647058824, green: 0.7254901961, blue: 0.7058823529, alpha: 1)
    }
    
    var messageTextColor:UIColor {
        return message.isFromCurrentUser ? .white : .white
    }
    
    var rightAnchorActive:Bool {
        return message.isFromCurrentUser
    }
    
    var leftAnchorActive:Bool {
        return !message.isFromCurrentUser
    }
    
    var shouldHideProfileImage:Bool {
        return message.isFromCurrentUser
    }
    init(message:Message) {
        self.message = message
    }
 }
