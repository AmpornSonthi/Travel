//
//  FeedViewModel.swift
//  Travel
//
//  Created by AOM on 7/17/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

struct FeedViewModel {
   
//    private let posts:Post
//    var postId:String
        var caption:String
        var likes:Int
        var imageUrl:String
    var ownerUid:String
//        var creationDate:Date!
    
    
//     var post: Post? {
//               didSet {
//                   guard let ownerUid = post?.ownerUid else { return }
//                   guard let imageUrl = post?.imageUrl else { return }
//                   guard let likes = post?.likes else { return }
//
//                   // ดีงข้อมูล user ที่ uid ตรงกับ postId
//                   Database.fetchUser(with: ownerUid) { (user) in
//                       self.profileImageView.loadImage(with: user.profileImageUrl)
//                       self.usernameButton.setTitle(user.username, for: .normal)
//                       self.configurePostCaption(user: user)
//                   }
//                   postImageView.loadImage(with: imageUrl)
//
//                   likesLabel.text = "\(likes) likes"
//                   configureLikeButton()
//                   configureCommentIndicatorView()
//               }
//           }
    
//    init(post:Post) {
//
////        self.posts = post
//        self.caption = post.caption
////        self.likes = post.likes
////        self.imageUrl = post.imageUrl
////        self.ownerUid = post.ownerUid
////        self.creationDate = post.creationDate
//    }
}
