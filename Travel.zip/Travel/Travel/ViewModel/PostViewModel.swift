//
//  PostViewModel.swift
//  Travel
//
//  Created by AOM on 7/22/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import Foundation
import UIKit

struct PostViewModel {
    
    let posts:Post
//    let user:User
    
//    var userInfoText:NSAttributedString {
//
//        let title = NSMutableAttributedString(string: "\(user.username)\n", attributes: [NSAttributedString.Key.font: UIFont(name: "Marker Felt", size: 18) ?? "System"])
//
//        title.append(NSAttributedString(string:"\(user.email)", attributes: [NSAttributedString.Key.font: UIFont(name: "Marker Felt", size: 18) ?? "System", NSAttributedString.Key.foregroundColor: UIColor.white]))
//        return title
//    }
    
    
    init(post:Post) {
        self.posts = post
//        self.user = post.user
    }
}
