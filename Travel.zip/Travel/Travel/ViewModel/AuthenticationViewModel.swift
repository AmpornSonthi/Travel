//
//  AuthenticationViewModel.swift
//  Travel
//
//  Created by AOM on 7/15/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

protocol FormViewModel {
    func updateForm()
}

protocol AuthenticationViewModel {
    var formIsValid:Bool {get}
    var shouldEnableButton:Bool {get}
    var buttonTitleColor:UIColor {get}
}

struct LoginViewModel:AuthenticationViewModel {
 
    var email: String?
    var password:String?
    
    var formIsValid: Bool {
        return email?.isEmpty == false
            && password?.isEmpty == false
    }
    
    var shouldEnableButton: Bool {
        return formIsValid
    }
    
    var buttonTitleColor: UIColor {
        return formIsValid ? .white : UIColor(white: 1, alpha: 0.5)
    }
    
}

struct SignUpViewModel:AuthenticationViewModel {
  
    var email: String?
    var username:String?
    var password:String?
      
    var formIsValid: Bool {
        return email?.isEmpty == false
            && username?.isEmpty == false
            && password?.isEmpty == false
    }
    
    var shouldEnableButton: Bool {
        return formIsValid
    }
    
    var buttonTitleColor: UIColor {
        return formIsValid ? .white : UIColor(white: 1, alpha: 0.5)
    }
    
}

struct TextViewModel:AuthenticationViewModel {
    
    var inputText:String?
    
    var formIsValid: Bool {
        return inputText?.isEmpty == false
    }
    
    var shouldEnableButton: Bool {
        return formIsValid
    }
    
    var buttonTitleColor: UIColor {
        return formIsValid ? .white:UIColor(white: 1, alpha: 0.5)
    }
    
}
