//
//  ConversationViewModel.swift
//  Travel
//
//  Created by AOM on 8/11/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import Foundation

struct ConversationViewModel {
    
    private let conversation:Conversation
    
    var profileImageUrl:URL? {
        return URL(string:conversation.user.profileImageUrl)
    }
    
    var timestamp:String {
        let date = conversation.message.timestamp.dateValue()
        let dateFormater = DateFormatter()
        dateFormater.dateFormat = "hh:mm a"
        return dateFormater.string(from:date)
    }
    
    init(conversation:Conversation) {
        self.conversation = conversation
    }
}
