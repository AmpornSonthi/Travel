//
//  ProfileHeadViewModel.swift
//  Travel
//
//  Created by AOM on 7/21/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

class ProfileHeadViewModel {

        // MARK: Lifecycle



}

//enum ProfileHeadViewModel:Int,CaseIterable {
//
//    case accountInfo = 0
//    case settings = 1
//
//    var description:String {
//        switch self {
//        case .accountInfo:return "Account Info"
//        case .settings:return "Setting Info"
//        }
//    }
//
////    var iconImageName:String {
////        switch self {
////        case .:
////            <#code#>
////        default:
////            <#code#>
////        }
////    }
//}

