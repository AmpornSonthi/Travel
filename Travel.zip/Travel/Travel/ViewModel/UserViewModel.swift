//
//  UserModel.swift
//  Travel
//
//  Created by AOM on 7/20/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import Foundation

struct UserViewModel {
    
    let email:String
    let username:String
    let profileImageUrl:String
    
    init(user:User) {
        
        email = user.email
        username = user.username
        profileImageUrl = user.profileImageUrl
    }
}
