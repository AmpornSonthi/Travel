//
//  ViewController.swift
//  Travel
//
//  Created by AOM on 7/11/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

