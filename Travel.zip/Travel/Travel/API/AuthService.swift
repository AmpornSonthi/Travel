//
//  AuthService.swift
//  Travel
//
//  Created by AOM on 7/15/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit
import Firebase
import GoogleSignIn

typealias FirestoreCompletion = (Error?) -> Void
typealias FacebookCompletion = (Error?) -> Void
typealias GoogleCompletion = (Error?) -> Void

//  Structure เป็น value type , Structure กับ class จะคล้ายๆกัน สามารถเก็บข้อมูลได้ และสามารถประกาศ property , method ต่างๆ ได้

//*** สิ่งที่ต่างคือ 1.Structure เป็น value ไม่ใช่ reference 2. Structure จะไม่มี อินเทอร์ริเเท้น คือ จะไม่สามารถ sub class ได้ เมื่อไม่มีการ sub class จะไม่มีการ overridering ไปด้วย ***

// ข้อดีของ Structure โค้ดตรงไปตรงมา , ไม่ต้องจัดการกับหน่วยความจำเนื่องจากเป็น value type

struct AuthCredentials {
    let email:String
    let password:String
    let username:String
}

struct AuthService {
    
    // static เป็นการประกาศ type method แต่ไม่สามารถ override class method ได้
    
    // Overriding คือ การเขียนทับ method ที่ได้ subclass มา
    // เช่นต้องการแก้ไข method ใน parent class เวลาที่ sub class มา
    
    static func logUserIn(withEmail email:String,password:String,completion:AuthDataResultCallback?) {
        Auth.auth().signIn(withEmail: email, password: password,completion:completion)
    }
    
    static func registerUser(withCredentials credentials:AuthCredentials,completion:@escaping(FirestoreCompletion)) {
        
        Auth.auth().createUser(withEmail: credentials.email, password: credentials.password) {
            (result,error) in
            
            if let error = error {
                print("debug error signing user up \(error.localizedDescription)")
                completion(error)
                return
            }
            
            guard let uid = result?.user.uid else { return }
             guard let profileImageUrl = result?.user.photoURL?.absoluteString else {return}
            
            let data = ["email":credentials.email,"username":credentials.username,"uid":uid,"profileImageUrl":profileImageUrl]
            
            COLLECTION_USER.document(uid).setData(data,merge: true,completion: completion)
        }
    }
    
    static func signInWithFaceBook(accessToken: String,completion:@escaping(FacebookCompletion)) {
        
        let credential = FacebookAuthProvider.credential(withAccessToken: accessToken)
        
        Auth.auth().signInAndRetrieveData(with: credential) { (result,error) in
            if let error = error {
                print("debug: failed to facebook Login Error \(error)")
                return
            }
            guard let uid = result?.user.uid else {return}
            guard let email = result?.user.email else { return }
            guard let username = result?.user.displayName else { return }
            guard let profileImageUrl = result?.user.photoURL?.absoluteString else {return}
            
            print("fb profileImageUrl \(profileImageUrl)")
            let data = ["email":email,"username":username,"uid":uid,"profileImageUrl":profileImageUrl] as [String : Any]
            
            COLLECTION_USER.document(uid).setData(data,merge: true,completion: completion)
            
        }
        
    }
    
    static func signInWithGoogle(didSignIn user:GIDGoogleUser,completion:@escaping(GoogleCompletion)) {
        guard let authentication = user.authentication else { return }
        
        //   ถ้า login ซ้ำกับเมล์ที่เคย login แบบปกติไปแล้ว จะไปทับอันเก่า
        //   เปลี่ยนเป็น login แบบ google
        
        let credential = GoogleAuthProvider.credential(withIDToken: authentication.idToken, accessToken: authentication.accessToken)
        
        Auth.auth().signIn(with: credential) {(result,error) in
            if let error = error {
                print("debug: failed to sign in with google : \(error.localizedDescription)")
                completion(error)
                return
            }
            
            guard let uid = result?.user.uid else {return}
            guard let email = result?.user.email else { return }
            guard let username = result?.user.displayName else { return }
            guard let profileImageUrl = result?.user.photoURL?.absoluteString else {return}
            
            let data = ["email":email,"username":username,"uid":uid,"profileImageUrl":profileImageUrl]
            
            COLLECTION_USER.document(uid).setData(data,merge: true,completion: completion)
        }
    }
    
    static func resetPassword(forEmail email:String,completion:SendPasswordResetCallback?) {
        Auth.auth().sendPasswordReset(withEmail: email, completion: completion)
    }
}
