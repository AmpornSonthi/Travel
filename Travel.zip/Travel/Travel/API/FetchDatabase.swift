//
//  Service.swift
//  Travel
//
//  Created by AOM on 7/16/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import Foundation
import Firebase
import FirebaseFirestore
import FirebaseFirestoreSwift

struct FetchDatabase {
    
    static func fetchAllUser(completion:@escaping([User]) -> Void) {
        
        COLLECTION_USER.getDocuments { (snapshot,error) in
            
            guard var users = snapshot?.documents.map({User(dictionary: $0.data()) }) else { return }
            
            if let i = users.firstIndex(where: {$0.uid == Auth.auth().currentUser?.uid})  {
                
                users.remove(at: i)
            }
              completion(users)
            
        }
        
    }
    
    
    static func fetchUserFeed(completion:@escaping(Error?) -> Void) {
        
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        print("feed posts 0 \(currentUid)")
        
        COLLECTION_USER_FEED.document(currentUid).getDocument { (snapshot,error) in
            snapshot?.data()?.forEach({ (key,value) in
                print("feed posts key \(key)")
            })
        }
        
    }
    
    static func fetchUserWithUid(with uid:String, completion:@escaping(User) -> Void) {
        
        COLLECTION_USER.document(uid).getDocument { (snapshot, error) in
            
            if let error = error {
                print("debug error fetch with user id  \(error.localizedDescription)")
            }
            
            guard let dictionary = snapshot?.data() else { return }
            
            //            let user = User(uid: uid, dictionary: dictionary)
            let user = User(dictionary: dictionary)
            completion(user)
            
        }
        
    }
    
    static func fetchPost(postId:String,completion:@escaping(Post) -> Void) {
        
        COLLECTION_POST.document(postId).getDocument { (snapshot,_) in
            
            guard let dictonary = snapshot?.data() else { return }
            
            guard let ownerUid = dictonary["ownerUid"] as? String  else { return }
            
            fetchUserWithUid(with: ownerUid, completion: {(user) in
                
                let post = Post(postId: postId, user: user, dictionary: dictonary)
                
                print("post post \(post.postId)")
                
                completion(post)
            })
            
        }
    }
    
    static func fetchUserPost(completion:@escaping(User) -> Void) {
        
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_USER.document(currentUid).getDocument { (snapshot,error) in
            
            if let error = error {
                print("debug error fetch with user id  \(error.localizedDescription)")
            }
            
            guard let dictonary = snapshot?.data() else { return }
            
            let uid = snapshot!.documentID
            let user = User(uid:uid,dictionary: dictonary)
            
            completion(user)
            
            print("debug snapshot fetchUserWithUid \(uid)")
        }
        
    }
    
    static func fetchConversations(completion:@escaping([Conversation]) -> Void) {
        
        var conversations = [Conversation]()
        guard let currentUid = Auth.auth().currentUser?.uid  else { return  }
        
        let query = COLLECTION_MESSAGES.document(currentUid).collection("recent-messages").order(by: "timestamp")
        
        query.addSnapshotListener { (snapshot, error) in
            snapshot?.documentChanges.forEach({ (change) in
                let dictionary = change.document.data()
                let message = Message(dictionary: dictionary)
                
                self.fetchUserWithUid(with: message.chatPartnerId) { (user) in
                    let conversation = Conversation(user: user, message: message)
                    conversations.append(conversation)
                    completion(conversations)
                }
            })
        }
    }
    
    static func fetchMessage(forUser user:User,completion:@escaping([Message]) -> Void) {
        
        var messages = [Message]()
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        let query = COLLECTION_MESSAGES.document(currentUid).collection(user.uid).order(by: "timestamp")
        
        query.addSnapshotListener { (snapshot, error) in
            snapshot?.documentChanges.forEach({ (change) in
                if change.type == .added {
                    let dictionary = change.document.data()
                    messages.append(Message(dictionary: dictionary))
                    completion(messages)
                }
            })
        }
    }
}


