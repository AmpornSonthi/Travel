//
//  MentionDatabase.swift
//  Travel
//
//  Created by AOM on 8/7/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import Firebase
import UIKit

extension UIViewController {
    
    func getMentionedUser(withUsername username:String) {
        
        COLLECTION_USER.getDocuments { (snapshot,error) in
            
            snapshot?.documents.forEach({document in
                
                let uid = document.documentID
                
                print("getMentionedUser uid \(uid)")
                
                COLLECTION_USER.document(uid).getDocument { (snapshot, error) in
                    
                    if username == document["username"] as? String  {
                        print("comment username \(username)")
                        FetchDatabase.fetchUserWithUid(with: uid) { (users) in
                            let profileVC = ProfileController(collectionViewLayout: UICollectionViewFlowLayout())
                            profileVC.user = users
                            self.navigationController?.pushViewController(profileVC, animated: true)
                            
                            return
                        }
                    }
                }
            })
        }
    }
    
    func uploadMentionNotification(forPostId postId:String,withText text:String,isForComment:Bool) {
        
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        let creationDate = Int(NSDate().timeIntervalSince1970)
        let words = text.components(separatedBy: .whitespacesAndNewlines)
        
        var mentionIntegerValue:Int!
        
        if isForComment {
            mentionIntegerValue = COMMENT_MENTION_INT_VALUE
        }else {
            mentionIntegerValue = POST_MENTION_INT_VALUE
        }
        
        for var word in words {
            if word.hasPrefix("@") {
                word = word.trimmingCharacters(in: .symbols)
                word = word.trimmingCharacters(in: .punctuationCharacters)
                
                COLLECTION_USER.getDocuments { (snapshot, error) in
                    
                    snapshot?.documents.forEach({ (document) in
                        
                        let uid = document.documentID
                        
                        COLLECTION_USER.document(uid).getDocument { (snapshot, error) in
                            
                            if word == document["username"] as! String {
                                
                                let notificationValue = ["postId": postId,
                                                         "uid": currentUid,
                                                         "type": mentionIntegerValue!,
                                                         "creationDate": creationDate] as [String: Any]
                                
                                if currentUid != uid {
                                    UploadDatabase.autoGenerateID { (id) in
                                        COLLECTION_NOTIFICATIONS.document(uid).setData([id : notificationValue],merge: true)
                                    }
                                }
                            }
                        }
                    })
                }
            }
            
        }
        
    }
}


