//////
//////  UploadDatabase.swift
//////  Travel
//////
//////  Created by AOM on 7/17/20.
//////  Copyright © 2020 AOM. All rights reserved.
//////
////
import UIKit
import Firebase
import Foundation

struct UploadDatabase {
    
    static func uploadImage(path:String,image:UIImage,completion:@escaping(String) -> Void) {
        
        guard let imageData = image.jpegData(compressionQuality: 0.75) else { return }
       
        let filename = NSUUID().uuidString
        let ref = Storage.storage().reference(withPath: "/\(path)/\(filename)")
        
        ref.putData(imageData,metadata: nil) {(metadata,error) in
            if let error = error {
                print("debug error uploading image \(error.localizedDescription)")
                return
            }
            ref.downloadURL{(url,error) in
                guard let imageUrl = url?.absoluteString else { return }
                
                print("downloadURL \(imageUrl)")
                
                completion(imageUrl)
            }
        }
    }
    
//    static func updateProfileImage(image:UIImage,completion:@escaping(String) -> Void) {
//
////        Storage.storage().reference(forURL: profileImageUrl).delete(completion: nil)
//
//        guard let imageData = image.jpegData(compressionQuality: 0.75) else { return }
//
//        let filename = NSUUID().uuidString
//        let ref = Storage.storage().reference(withPath: "/profile_images/\(filename)")
//        ref.putData(imageData, metadata: nil) {(metadata,error) in
//            if let error = error {
//                print("debug error uploading profile image \(error.localizedDescription)")
//                return
//            }
//            ref.downloadURL { (url,error) in
//                guard let imageUrl = url?.absoluteString else { return }
//
//                print("downloadURL profile image \(imageUrl)")
//
//                completion(imageUrl)
//            }
//        }
//    }
    
    static func sharePosts(caption:String,imageUrl:String,completion:@escaping(Error?) -> Void) {
        
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        let data = ["ownerUid":uid,"caption":caption,"likes":0,"imageUrl":imageUrl,
                    "creationDate":Int(NSDate().timeIntervalSince1970),"timestamp": FieldValue.serverTimestamp()] as [String : Any]
        
        var ref: DocumentReference? = nil
        ref = COLLECTION_POST.addDocument(data:data) { err in
            if let err = err {
                print("Error adding document: \(err)")
            } else {
                print("Document added with ID: \(ref!.documentID)")
                
                COLLECTION_USER_POST.document(uid).setData([ref!.documentID : 1],merge: true,completion: completion)
                
                //  upload UserFeed
                updateUserFeed(with: ref!.documentID) { (error) in
                    if let error = error {
                        print("debug updateUserFeed error \(error.localizedDescription)")
                        return
                    }
                }
                
                //  upload hashtag
                if caption.contains("#") {
                    uploadPostHashtag(withPostId: ref!.documentID, caption: caption) {(error) in
                        if let error = error {
                            print("debug uploadPostHashtag error \(error.localizedDescription)")
                            return
                        }
                    }
                }
                
                // upload mention notification
                if caption.contains("@") {
                    print("caption \(caption)")
                    uploadMentionNotification(forPostId: ref!.documentID, withText: caption, isForComment: false) {(error) in
                        if let error = error {
                            print("debug uploadMentionNotification error \(error.localizedDescription)")
                            return
                        }
                    }
                }
            }
        }
        
    }
    
    static func updateUserFeed(with postId:String,completion:@escaping(Error?) -> Void) {
        
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        let values = [postId:1]
        
        // if press follower user
        COLLECTION_USER_FOLLOWER.document(currentUid).addSnapshotListener { (snapshot, error) in
            
            let followerUid = snapshot?.documentID as! String
            
            print("updateUserFeed followerUid \(followerUid)")
            
            COLLECTION_USER_FEED.document(followerUid).setData(values,merge: true)
            
                print("updateUserFeed values \(values)")
            
        }
        
         COLLECTION_USER_FEED.document(currentUid).setData(values,merge: true)
    }
    
    static func uploadPostHashtag(withPostId postId:String,caption:String,completion:@escaping(Error?) -> Void) {
        
        let words:[String] = caption.components(separatedBy: .whitespacesAndNewlines)
        
        for var word in words {
            if word.hasPrefix("#") {
                word = word.trimmingCharacters(in: .punctuationCharacters)
                word = word.trimmingCharacters(in: .symbols)
                
                let hashtagValues = [postId:1]
                COLLECTION_HASHTAG_POST.document(word.lowercased()).setData(hashtagValues,merge: true,completion: completion)
            }
        }
    }
    
    static func uploadMentionNotification(forPostId postId:String,withText text:String,isForComment:Bool,completion:@escaping(Error?) -> Void) {
        
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        let creationDate = Int(NSDate().timeIntervalSince1970)
        let words = text.components(separatedBy: .whitespacesAndNewlines)
        
        var mentionIntegerValue:Int!
        
        if isForComment {
            mentionIntegerValue = COMMENT_MENTION_INT_VALUE
        }else {
            mentionIntegerValue = POST_MENTION_INT_VALUE
        }
        
        for var word in words {
            if word.hasPrefix("@") {
                word = word.trimmingCharacters(in: .symbols)
                word = word.trimmingCharacters(in: .punctuationCharacters)
                
                COLLECTION_USER.getDocuments() { (querySnapshot, err) in
                    
                    if let err = err {
                        print("Error Notification documents: \(err)")
                    } else {
                        for document in querySnapshot!.documents {
                            print("Notification id \(document.documentID)")
                            
                            COLLECTION_USER.document(document.documentID).addSnapshotListener { (snapshot, error) in
                                
                                if  word == snapshot?.data()?["username"] as! String {
                                    
                                    print("Notification username \(word)")
                                    
                                    let notificationValues = ["postId": postId,
                                                              "uid": currentUid,
                                                              "type": mentionIntegerValue!,
                                                              "creationDate": creationDate] as [String: Any]
                                    
                                    if currentUid != document.documentID {
                                        COLLECTION_NOTIFICATIONS.document(document.documentID).setData(notificationValues,merge: true,completion: completion)
                                        
                                    }
                                }
                            }
                        }
                    }
                }
                
            }
            
        }
    }
    
    static func uploadMessage(_ message:String, to user:User, completion:((Error?) -> Void)?) {
     
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        let data = ["text":message, "fromId":currentUid, "toId":user.uid,"timestamp":Timestamp(date: Date())] as [String:Any]
        
        //  add collection -> document
        COLLECTION_MESSAGES.document(currentUid).collection(user.uid).addDocument(data: data) {_ in
            
            COLLECTION_MESSAGES.document(user.uid).collection(currentUid).addDocument(data: data, completion:completion)
            
            // setdata to collection recent-messages
            COLLECTION_MESSAGES.document(currentUid).collection("recent-messages").document(user.uid).setData(data)
            COLLECTION_MESSAGES.document(user.uid).collection("recent-messages").document(currentUid).setData(data)
        }
        
    }
    
    static func autoGenerateID(completion:@escaping(String) -> Void) {
        
        let valueId = ["timestamp": FieldValue.serverTimestamp()]
        COLLECTION_GENID.addDocument(data: valueId) { (error) in
            
            COLLECTION_GENID.order(by: "timestamp").addSnapshotListener { (document, _) in
                guard let lastSnapshot = document?.documents.last?.documentID else {
                    return
                }
                
                completion(lastSnapshot)
            }
            
        }
    }
        
        
        //        static func fetchAllPost(completion:@escaping([Post]) -> Void) {
        //
        //            var users = [Post]()
        //
        //            COLLECTION_USER.getDocuments { (snapshot,error) in
        //
        //                if let error = error {
        //                    print("debug error fetch user \(error.localizedDescription)")
        //                }
        //
        //                snapshot?.documents.forEach({document in
        //
        //                    let dictionary = document.data()
        //                    let user = User(dictionary: dictionary)
        //
        //                    users.append(user)
        //
        //                    print("fetchUsers user \(user)")
        //
        //
        //                })
        //                completion(users)
        //            }
        //        }
        
}
