//
//  PostController.swift
//  Travel
//
//  Created by AOM on 7/22/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

class PostController: UIViewController,UITextViewDelegate {
    
    // MARK: - Properties
    
    var imagesUrl:String!
    private var posts = [Post]()
    
    private var viewModel = TextViewModel()
    
    var selectedImage:UIImage?
    
    let photoImageView:CustomImageView = {
        let iv = CustomImageView()
        return iv
    }()
    
    let captionTextView:UITextView = {
        let tv = UITextView()
        tv.backgroundColor = UIColor.groupTableViewBackground
        tv.font = UIFont(name: "Marker Felt", size: 25)!
        return tv
    }()
    
    private lazy var actionButton:AuthButton = {
        let button = AuthButton(type: .system)
        button.title = "Share"
        button.isEnabled = false
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = #colorLiteral(red: 0.9405841231, green: 0.5281627774, blue: 0.4746308327, alpha: 1)
        button.addTarget(self, action: #selector(handelShare), for: .touchUpInside)
        return button
    }()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureViewComponents()
        
        // load image
        loadImage()
        
    }
    
    // MARK : Helpers
    
    func loadImage() {
        
        guard let selectedImage = self.selectedImage else { return }
        photoImageView.image = selectedImage
        
    }
    
    // MARK: - API
    
    func configureViewComponents() {
        
        captionTextView.delegate = self
        captionTextView.setPlaceholder()
        updateForm()
        
        view.backgroundColor = .white
        
        view.addSubview(photoImageView)
        photoImageView.anchor(top: view.topAnchor, left: view.leftAnchor, bottom: nil, right: nil, paddingTop: 92, paddingLeft: 12, paddingBottom: 0, paddingRight: 0, width: 120, height: 220)
        
        view.addSubview(captionTextView)
        captionTextView.anchor(top: view.topAnchor, left: photoImageView.rightAnchor, bottom: nil, right: view.rightAnchor, paddingTop: 92, paddingLeft: 12, paddingBottom: 0, paddingRight: 12,height: 220)
        
        view.addSubview(actionButton)
        actionButton.anchor(top: photoImageView.bottomAnchor, left: view.leftAnchor, bottom: nil, right: view.rightAnchor, paddingTop: 12, paddingLeft: 30, paddingBottom: 0, paddingRight: 30)
    }
    
    // MARK: - Handlers 
    
    @objc func handelShare() {
        
        guard let selectedImage = self.selectedImage else { return }
        guard let caption = self.captionTextView.text else { return  }
        
        self.showLoader(true)
        
        UploadDatabase.uploadImage(path:"post_images",image: selectedImage) {imageUrl in
           
            // update user-post structure
            UploadDatabase.sharePosts(caption: caption,imageUrl: imageUrl ){(error)in
                
                self.showLoader(false)
                if let error = error {
                    print("debug sharePosts error \(error.localizedDescription)")
                    return
                }
                
                // return to feed page
                self.dismiss(animated: true, completion: {
                    self.tabBarController?.selectedIndex = 0
                })
            }
            
        }
        
    }
    
    func textViewDidChange(_ textView: UITextView) {
        print("textViewDidChange")
        textView.checkPlaceholder()
        if textView == captionTextView {
            viewModel.inputText = textView.text
        }
        
        updateForm()
    }
}

// MARK: - FormViewModel

extension PostController:FormViewModel {
    func updateForm() {
        actionButton.isEnabled = viewModel.shouldEnableButton
        actionButton.setTitleColor(viewModel.buttonTitleColor, for: .normal)
        
    }
}
