//
//  ProfileController.swift
//  Travel
//
//  Created by AOM on 7/19/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit
import Firebase

private let reuseIdentifier = "Cell"
private let headerIdentifier = "UserProfileHeader"

class ProfileController: UICollectionViewController {
    
    var user:User?
    private var posts = [Post]()
    
    lazy var backButton: NavigationButton = {
        let button = NavigationButton(type: .system)
        button.addTarget(self, action: #selector(handleDismissal), for: .touchUpInside)
        button.isHidden = true
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureRefreshControl()
        configureUI()
        checkUser()
    }
    
    
    func checkUser() {
        
        // fetch user data
        if self.user == nil {
    
            fetchCurrentUserData()
        }
        
        // fetch posts
        fetchPosts()
        
    }
    
    func fetchPosts() {
        
        showLoader(true)
        
        var uid:String!
        
        if let user = self.user {
            uid = user.uid
        }else {
            uid = Auth.auth().currentUser?.uid
        }
        
        self.collectionView.refreshControl?.endRefreshing()
        
        COLLECTION_USER_POST.document(uid).getDocument { (snapshot,error) in
            
            self.showLoader(false)
            if let error = error {
                print("debug error user-post \(error.localizedDescription)")
                return
            }
            
            snapshot?.data()?.forEach({ (key,_) in
                self.fetchPost(postId: key)
            })
        }
    }
    
    func fetchPost(postId: String) {
        
        FetchDatabase.fetchPost(postId: postId) {( post) in
            self.posts.append(post)
            self.posts.sort { (post1, post2) -> Bool in
                return post1.creationDate > post2.creationDate
            }
            
            self.collectionView.reloadData()
        }
        
    }
    
    func fetchCurrentUserData() {

        showLoader(true)
        FetchDatabase.fetchUserPost { user in
            self.user = user
            self.collectionView?.reloadData()
            self.showLoader(false)
        }
    }
    
    // MARK: - Handlers
    @objc func handleRefresh() {
        posts.removeAll(keepingCapacity: false)
        fetchPosts()
        collectionView?.reloadData()
    }
    
    @objc func handleDismissal() {
        //        navigationController!.popViewController(animated: true)
        dismiss(animated: true, completion: nil)
    }
    
    func configureRefreshControl() {
        let refreshControl = UIRefreshControl()
        collectionView.addSubview(refreshControl)
        refreshControl.anchor(top:collectionView.topAnchor ,paddingTop: -20)
        refreshControl.centerX(inView: collectionView)
        refreshControl.addTarget(self, action: #selector(handleRefresh), for: .valueChanged)
        collectionView?.refreshControl = refreshControl
    }
    
    func configureUI() {
        
        navigationController?.navigationBar.isHidden = true
        
        collectionView.backgroundColor = .white
        self.collectionView.register(ProfileHeadCell.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: headerIdentifier)
        self.collectionView.contentInset = UIEdgeInsets(top: -50, left: 0, bottom: 0, right: 0)
        self.collectionView!.register(ProfileCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        
        self.view.addSubview(backButton)
        backButton.anchor(top:  self.collectionView.topAnchor, left:  self.collectionView.leftAnchor, paddingTop: 30, paddingLeft: 16)
          
    }
    
}

// MARK: - UICollectionViewFlowLayout

extension ProfileController:UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (view.frame.width - 2) / 3
        return CGSize(width: width, height: width)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: view.frame.width, height: 310)
    }
}

// MARK: UICollectionViewDataSource

extension ProfileController {
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    override func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        
        if posts.count > 9 {
            if indexPath.item == posts.count - 1 {
                fetchPosts()
            }
        }
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return posts.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! ProfileCell
        cell.post = posts[indexPath.item]
        
        return cell
    }
    
}

extension ProfileController {
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let feedVC = FeedController(collectionViewLayout: UICollectionViewFlowLayout())
        
        feedVC.viewSinglePost = true
        feedVC.userProfileController = self
        
        feedVC.post = posts[indexPath.item]
        
        navigationController?.pushViewController(feedVC, animated: true)
    }
}

// MARK: ProfileHeadCellDelegate

extension ProfileController:ProfileHeadCellDelegate {
    
    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: headerIdentifier, for: indexPath) as! ProfileHeadCell
     
        header.user = self.user
        header.delegate = self
         
        return header
    }
    
    func setUserStats(for header: ProfileHeadCell) {
        
        guard let uid = header.user?.uid else { return }
        
        var numberOfFollwers = 0
        var numberOfFollowing = 0
        var numberPost = 0
        
        // get number of user-followers
        COLLECTION_USER_FOLLOWER.document(uid).getDocument { (snapshot,error) in
            
            if let error = error {
                print("debug error fetch with user id  \(error.localizedDescription)")
                return
            } else {
                numberOfFollwers = (snapshot?.data()?.count ?? 0) as Int
            }
            
             let attributedText = NSMutableAttributedString(string: "\(numberOfFollwers)\n", attributes: [NSAttributedString.Key.font: UIFont(name: "MarkerFelt-Wide", size: 18)])
                  attributedText.append(NSAttributedString(string: "Follow", attributes: [NSAttributedString.Key.font:  UIFont(name: "Marker Felt", size: 16), NSAttributedString.Key.foregroundColor: UIColor.white]))
            
            header.followersLabel.attributedText = attributedText
            
        }
        
        // get number of user-following
        COLLECTION_USER_FOLLOWING.document(uid).getDocument { (snapshot,error) in
            
            if let error = error {
                print("debug error fetch with user id  \(error.localizedDescription)")
                return
            } else {
                numberOfFollowing = (snapshot?.data()?.count ?? 0) as Int
            }
            
            let attributedText = NSMutableAttributedString(string: "\(numberOfFollowing)\n", attributes: [NSAttributedString.Key.font: UIFont(name: "MarkerFelt-Wide", size: 18)])
            attributedText.append(NSAttributedString(string: "following", attributes: [NSAttributedString.Key.font:  UIFont(name: "Marker Felt", size: 16), NSAttributedString.Key.foregroundColor: UIColor.white]))
            
            header.followingLabel.attributedText = attributedText
        }
        
        // get number of post
        COLLECTION_USER_POST.document(uid).getDocument { (snapshot,error) in
            
            if let error = error {
                print("debug error fetch with user id  \(error.localizedDescription)")
                return
            } else {
                numberPost = (snapshot?.data()?.count ?? 0) as Int
            }
            let attributedText = NSMutableAttributedString(string: "\(numberPost)\n", attributes: [NSAttributedString.Key.font: UIFont(name: "MarkerFelt-Wide", size: 18)])
            attributedText.append(NSAttributedString(string: "post", attributes: [NSAttributedString.Key.font:  UIFont(name: "Marker Felt", size: 16), NSAttributedString.Key.foregroundColor: UIColor.white]))
          
            header.postLabel.attributedText = attributedText
        }
        
    }
    
    // MARK: - UserProfileHeader
      
    func handleEditFollowTapped(for header: ProfileHeadCell) {
        
        guard let user = header.user else { return }
        
        print("handleEditFollowTapped uid \(String(describing: header.user?.uid))")
        
        if header.editProfileButton.titleLabel?.text == "..." {
            
            let editProfileController = EditProfileController()
            editProfileController.user = user
            editProfileController.userProfileController = self
            let navigationController = UINavigationController(rootViewController: editProfileController)
            present(navigationController, animated: true, completion: nil)
        } else {
            // handles user follow/unfollow
            if header.editProfileButton.titleLabel?.text == "Follow" {
                header.editProfileButton.setTitle("Following", for: .normal)
                user.follow()
            } else {
                header.editProfileButton.setTitle("Follow", for: .normal)
                user.unfollow()
            }
        }
    }
}
