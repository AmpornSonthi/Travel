//
//  CommentController.swift
//  Travel
//
//  Created by AOM on 8/6/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit
import Firebase

private let reuseIdentifer = "CommentCell"

class CommentController: UICollectionViewController {
    
    // MARK: - Properties
    
    var comments = [Comment]()
    var post: Post?
    
    lazy var containerView:CommentInputAccesoryView = {
        let frame = CGRect(x: 0, y: 0, width: view.frame.width, height: 50)
        let containerView = CommentInputAccesoryView(frame: frame)
        
        containerView.delegate = self
        
        return containerView
    }()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureUI()
        
        // fetch comments
        fetchComments()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("Comment viewWillAppear ")
        
        tabBarController?.tabBar.isHidden = true
    }
    
    override var inputAccessoryView: UIView? {
        //  View on top keyboard
        get {
            return containerView
        }
    }
    
    override var canBecomeFirstResponder: Bool {
        
        print("Comment canBecomeFirstResponder ")
        return true
    }
    
    //  MARK: - Helpers
    
    func configureUI() {
        
        configureNavigationBar()
        
        // register cell class
        collectionView?.register(CommentCell.self, forCellWithReuseIdentifier: reuseIdentifer)
        
        // configure collection view
        collectionView?.backgroundColor = .white
        collectionView?.alwaysBounceVertical = true
        collectionView?.keyboardDismissMode = .interactive
        collectionView?.contentInset = UIEdgeInsets(top: 10, left: 0, bottom: 16, right: 0)
        collectionView?.scrollIndicatorInsets = UIEdgeInsets(top: 10, left: 0, bottom: 16, right: 0)
        
        // navigation title
        navigationItem.title = "Comments"
        
    }
    
    func configureNavigationBar() {
        
        let attributes = [NSAttributedString.Key.font: UIFont(name: "Marker Felt", size: 23)!]
        UINavigationBar.appearance().titleTextAttributes = attributes
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: #imageLiteral(resourceName: "cancel_shadow"), style: .plain, target: self, action: #selector(handleDismis))
        self.navigationItem.rightBarButtonItem?.tintColor = .black
        
        self.navigationItem.title = "^-^ Comment ^-^"
        
    }
    
    // MARK: - Handlers
    
    @objc func handleDismis() {
        dismiss(animated: true, completion: nil)
    }
    
    // MARK: - API
    
    func fetchComments() {
        
        
        guard let postId = self.post?.postId else { return }
        
        var commentUId = ""
        
        COLLECTION_COMMENT.document(postId).getDocument { (snapshot,error) in
            self.collectionView.refreshControl?.endRefreshing()
            
            snapshot?.data()?.forEach({ (key,value) in
                
                let dictionarys = value as! Dictionary<String, Any>
                
                commentUId = dictionarys["uid"] as! String
                
                self.fetcComment(withPostId: commentUId as! String,dictionary: dictionarys)
            })
        }
        
    }
    
    func uploadCommentNotificationToServer() {
        
        //        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        //        guard let postId = self.post?.postId else { return }
        //        guard let uid = post?.user?.uid else { return }
        //        let creationDate = Int(NSDate().timeIntervalSince1970)
        //
        //        // notification values
        //        let values = ["checked": 0,
        //                      "creationDate": creationDate,
        //                      "uid": currentUid,
        //                      "type": COMMENT_INT_VALUE,
        //                      "postId": postId] as [String : Any]
        //
        //        // upload comment notification to server not current user
        //
        //        if uid != currentUid {
        //
        //            UploadDatabase.autoGenerateID { (id) in
        //
        //                COLLECTION_NOTIFICATIONS.document(uid).setData([id : values],merge: true, completion: nil)
        //            }
        //
        //        }
    }
    
    func fetcComment(withPostId postId:String,dictionary:Any) {
        
        FetchDatabase.fetchUserWithUid(with:postId) { (users) in
            
            let comment = Comment(user: users, dictionary: dictionary as! Dictionary<String, Any>)
            
            self.comments.append(comment)
            
            self.comments.sort { (comments1, comments2) -> Bool in
                
                return comments1.creationDate > comments2.creationDate
            }
            
            self.collectionView.reloadData()
            
        }
    }
}
// MARK: - UICollectionViewDataSource

extension CommentController:UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let frame = CGRect(x: 0, y: 0, width: view.frame.width, height: 50)
        let dummyCell = CommentCell(frame: frame)
        dummyCell.comment = comments[indexPath.item]
        dummyCell.layoutIfNeeded()
        
        let targetSize = CGSize(width: view.frame.width, height: 1000)
        let estimatedSize = dummyCell.systemLayoutSizeFitting(targetSize)
        
        let height = max(40 + 8 + 8, estimatedSize.height)
        return CGSize(width: view.frame.width, height: height)
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return comments.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifer, for: indexPath) as! CommentCell
        
        cell.comment = comments[indexPath.item]
        
        return cell
    }
    
}

// MARK: - CommentInputAccesoryViewDelegate

extension CommentController:CommentInputAccesoryViewDelegate {
    
    func didSubmit(forComment comment: String, refreshControll: UIRefreshControl) {
        
        self.showLoader(true)
        
        guard let postId = self.post?.postId else { return }
        guard let uid = Auth.auth().currentUser?.uid else { return }
        let creationDate = Int(NSDate().timeIntervalSince1970)
        
        let values = ["commentText": comment,
                      "creationDate": creationDate,
                      "uid": uid] as [String : Any]
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            
            UploadDatabase.autoGenerateID { (id) in
                
                COLLECTION_COMMENT.document(postId).setData([id : values],merge:true) { (error) in
                    
                    self.uploadCommentNotificationToServer()
                    
                    if comment.contains("@") {
                        self.uploadMentionNotification(forPostId: postId, withText: comment, isForComment: true)
                    }
                    self.comments.removeAll()
                    self.containerView.clearCommentTextView()
                }
            }
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.showLoader(false)
            self.comments.removeAll()
            self.fetchComments()
            self.collectionView?.refreshControl = refreshControll
            
        }
    }
    
}
