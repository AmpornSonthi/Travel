//
//  FeedController.swift
//  Travel
//
//  Created by AOM on 7/15/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit
import Firebase

private let reuseIdentifier = "Cell"
let headerCell = "Header"

class FeedController: UICollectionViewController {
    
    // MARK: - Properties
    
    var posts = [Post]()
    var viewSinglePost = false
    var post: Post?
    private var currentKey: String?
    var userProfileController: ProfileController?
    //    var refreshControll2: UIRefreshControl?
    
    var messsageNotificationView:MessageNotificationView = {
        let view = MessageNotificationView()
        return view
    }()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureRefresh()
        authenticateUser()
        configureUI()
        
    }
    
    // กำลังเปิด
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        setUnreadMessageCount()
        
        self.showLoader(true)
        self.posts.removeAll()
        
        if self.posts != nil {
            
            if !viewSinglePost {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    self.showLoader(false)
                    self.posts.removeAll()
                    self.fetchPosts()
                    //                    self.collectionView?.refreshControl = self.refreshControll2
                    
                }
            }
            return
        }
    }
    
    //  MARK: - Helpers
    
    func configureUI() {
        
        collectionView?.backgroundColor = .white
        configureNavigationBar()
        
        let headerNib = UINib.init(nibName: "FeedHeader", bundle: nil)
        collectionView.register(headerNib, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: headerCell)
        
        // register cell class
        self.collectionView!.register(FeedCell.self, forCellWithReuseIdentifier: reuseIdentifier)
    }
    
    func configureNavigationBar() {
        
        //        if !viewSinglePost {
        
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(handleLogout))
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: #imageLiteral(resourceName: "ic_send_message"), style: .plain, target: self, action: #selector(handleMessage))
        //        }
        
        
        let attributes = [NSAttributedString.Key.font: UIFont(name: "Marker Felt", size: 23)!]
        UINavigationBar.appearance().titleTextAttributes = attributes
        
        self.navigationItem.title = "^-^ Travel ^-^"
        
    }
    
    func configureRefresh() {
        // configure refresh control
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(handleRefresh), for: .valueChanged)
        self.collectionView?.refreshControl = refreshControl
        
        //        let refreshControl = UIRefreshControl()
        //                collectionView.addSubview(refreshControl)
        //                 refreshControl.anchor(top: collectionView.topAnchor ,paddingTop:-20)
        //                 refreshControl.centerX(inView:  collectionView)
        //                 refreshControl.addTarget(self, action: #selector(handleRefresh), for: .valueChanged)
        //        collectionView?.refreshControl = refreshControl
    }
    
    func setUnreadMessageCount() {
        //        if !viewSinglePost {
        //            getUnreadMessageCount { (unreadMessageCount) in
        //                guard unreadMessageCount != 0 else { return }
        //                self.navigationController?.navigationBar.addSubview(self.messageNotificationView)
        //                self.messageNotificationView.anchor(top: self.navigationController?.navigationBar.topAnchor, left: nil, bottom: nil, right: self.navigationController?.navigationBar.rightAnchor, paddingTop: 0, paddingLeft: 0, paddingBottom: 0, paddingRight: 4, width: 20, height: 20)
        //                self.messageNotificationView.layer.cornerRadius = 20 / 2
        //                self.messageNotificationView.notificationLabel.text = "\(unreadMessageCount)"
        //            }
        //        }
    }
    
    // MARK : Helpers
    
    func authenticateUser()  {
        
        if Auth.auth().currentUser == nil {
            DispatchQueue.main.async {
                self.presentLoginController()
            }
        }
    }
    
    fileprivate func presentLoginController() {
        let controller = AuthController()
        controller.delegate = self
        let nav = UINavigationController(rootViewController: controller)
        nav.modalPresentationStyle = .fullScreen
        self.present(nav, animated: true, completion: nil)
    }
    
    // MARK: - Handlers
    
    @objc func handleLogout() {
        
        let alert = UIAlertController(title: nil, message: "Are you sure you want to log out?", preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Log Out", style: .destructive, handler: { _ in
            self.logout()
            
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    @objc func handleMessage() {
        let messageVC = ConversationsController()
        let nav = UINavigationController(rootViewController: messageVC)
        nav.modalPresentationStyle = .fullScreen
        navigationController?.present(nav, animated: true, completion: nil)
    }
    
    @objc func handleRefresh() {
        posts.removeAll(keepingCapacity: false)
        self.currentKey = nil
        fetchPosts()
        collectionView?.reloadData()
        
        print("handleRefresh")
    }
    
    // MARK: - API
    
    func fetchPosts() {
        
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_USER_FEED.document(currentUid).getDocument { (snapshot,_) in
            self.collectionView.refreshControl?.endRefreshing()
            
            snapshot?.data()?.forEach({ (key,value) in
                print("feed posts key \(key)")
                self.fetchPost(withPostId: key)
            })
            
            self.currentKey = snapshot?.data()?.keys.first
            print("feed posts currentKey \(currentUid)")
            
        }
    }
    
    func fetchPost(withPostId postId:String) {
        
        FetchDatabase.fetchPost(postId: postId) { (postss) in
            
            print("posts id \(postId)")
            
            self.posts.append(postss)
            
            self.posts.sort { (post1, post2) -> Bool in
                return post1.creationDate > post2.creationDate
            }
            
            self.collectionView.reloadData()
        }
    }
    
    func logout() {
        do {
            try Auth.auth().signOut()
            self.presentLoginController()
        } catch {
            print("debug: error signing out ")
        }
    }
    
}

// MARK: - UICollectionViewDelegateFlowLayout

extension FeedController:UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = view.frame.width
        var height = width / 1.2
        height += 5
        return CGSize(width: width, height: height)
    }
}

// MARK: - UICollectionViewDataSource

extension FeedController {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: 50)
    }
    
    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        if (kind == UICollectionView.elementKindSectionHeader) {
            let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: headerCell, for: indexPath) as! FeedHeader
            
            return headerView
        } else {
            
        }
        fatalError()
    }
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if viewSinglePost {
            return 1
        }else {
            return posts.count
        }
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! FeedCell
        
        cell.delegate = self
        
        if viewSinglePost {
            if let post = self.post {
                cell.posts = post
            }
        } else {
            if posts != nil {
                cell.posts = posts[indexPath.item]
            }
        }
        
        return cell
    }
}

// MARK: - FeedCellDelegate

extension FeedController:FeedCellDelegate {
    
    func handleUsernameTapped(for cell: FeedCell) {
        
        guard let post = cell.posts else { return }
        let userProfileVC = ProfileController(collectionViewLayout: UICollectionViewFlowLayout())
        userProfileVC.user = post.user
        userProfileVC.backButton.isHidden = false
        userProfileVC.modalTransitionStyle   = .crossDissolve;
        userProfileVC.modalPresentationStyle = .overCurrentContext
        
        self.present(userProfileVC, animated: true, completion: nil)
        
    }
    
    func handleConfigureLikeButton(for cell: FeedCell) {
        
        guard let post = cell.posts else { return }
        guard let postId = post.postId else { return }
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        var keys = ""
        
        COLLECTION_USER_LIKE.document(currentUid).getDocument { (snap, _) in
            
            snap?.data()?.forEach({ (key,value) in
                
            
                
                if postId == key {
                    keys = key
                }
            })
            if postId == keys {
                post.didLike = true
                cell.likeButton.setImage(#imageLiteral(resourceName: "feed-heart"), for: .normal)
            }
            else {
                post.didLike = false
                cell.likeButton.setImage(#imageLiteral(resourceName: "like_unselected"), for: .normal)
            }
        }
        
        
    }
    
    func handleLikeTapped(for cell: FeedCell, isDoubleTap: Bool) {
        
        guard let post = cell.posts else { return }
        
        if post.didLike {
            // handle unlike post
            if !isDoubleTap {
                post.adjustLikes(addLike: false, completion: { (likes) in
                    cell.likesLabel.text = " \(likes)"
                    cell.likeButton.setImage(#imageLiteral(resourceName: "like_unselected"), for: .normal)
                })
            }
        } else {
            // handle like post
            post.adjustLikes(addLike: true, completion: { (likes) in
                cell.likesLabel.text = " \(likes)"
                cell.likeButton.setImage(#imageLiteral(resourceName: "feed-heart"), for: .normal)
            })
        }
    }
    
    func configureCommentIndicatorView(for cell: FeedCell) {
        
        guard let post = cell.posts else { return }
        guard let postId = post.postId else { return }
        
        COLLECTION_COMMENT.document(postId).getDocument { (snapshot, _) in
            if snapshot!.exists {
                cell.addCommentIndicatorView(toStackView: cell.stackView)
            }else {
                cell.commentIndicatorView.isHidden = true
            }
        }
        
    }
    
    func handleCommentTapped(for cell: FeedCell) {
        guard let post = cell.posts else { return }
        let commentVC = CommentController(collectionViewLayout: UICollectionViewFlowLayout())
        commentVC.post = post
        let nav = UINavigationController(rootViewController: commentVC)
        nav.modalPresentationStyle = .fullScreen
        navigationController?.present(nav, animated: true, completion: nil)
    }
    
}

//// MARK: - AuthenticationDelegate
//
extension FeedController:AuthenticationDelegate {
    func authenticationComplete() {
        dismiss(animated:true , completion: nil)
    }
    
}


