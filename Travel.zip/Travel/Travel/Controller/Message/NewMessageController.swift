//
//  NewMessageControllerTableViewController.swift
//  Travel
//
//  Created by AOM on 8/9/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit
import Firebase

private let reuseIdentifier = "UserCell"

protocol NewMessageControllerDelegate:class {
    func controller(_ controller: NewMessageController,wantToStartChatWith user: User)
}

class NewMessageController: UITableViewController {
    
    // MARK: - Properties
    
    private var user = [User]()
    weak var delegate:NewMessageControllerDelegate?
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureTableview()
        configureNavigationBar()
        fetchUsers()
    }
    
    // MARK: - Handlers
    
    func configureTableview() {
        
        // register cell class
        tableView.register(UserCell.self, forCellReuseIdentifier: reuseIdentifier)
        
        // separator insets
        tableView.separatorInset = UIEdgeInsets(top: 20, left: 65, bottom: 0, right: 0)
    }
    
    
    func configureNavigationBar() {
        
        let attributes = [NSAttributedString.Key.font: UIFont(name: "Marker Felt", size: 23)!]
        UINavigationBar.appearance().titleTextAttributes = attributes
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: #imageLiteral(resourceName: "cancel_shadow"), style: .plain, target: self, action: #selector(handleDismis))
        self.navigationItem.rightBarButtonItem?.tintColor = .black
        
        self.navigationItem.title = "^-^ Friends ^-^"
        
        //        fetchMessages()
    }
    
    // MARK: - API
    
    func fetchUsers() {
        FetchDatabase.fetchAllUser { (users) in
            self.user = users
            self.tableView.reloadData()
        }
    }
    
    // MARK: - Actions
    
    @objc func handleDismis() {
        dismiss(animated: true, completion: nil)
    }
}

// MARK: - UITableViewDataSource

extension NewMessageController {
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return user.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! UserCell
        let viewModel = UserViewModel(user: user[indexPath.row])
        cell.viewModel = viewModel
        return cell
    }
}

// MARK: - UITableViewDataDelegate

extension NewMessageController {
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        delegate?.controller(self, wantToStartChatWith: user[indexPath.row])
    }
    
}
