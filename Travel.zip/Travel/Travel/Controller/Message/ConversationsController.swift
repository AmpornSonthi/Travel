//
//  MessageController.swift
//  Travel
//
//  Created by AOM on 7/18/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit
import Firebase

private let reuseIndentifier = "Cells"

class ConversationsController: UIViewController {
    
    // MARK: - Properties
    
    private var conversations = [Conversation]()
    private var conversationsDic = [String:Conversation]()
    private let headerView = MessageHead()
    private let tableView = UITableView()
    
    private let newMessageButton:AuthButton = {
        let button = AuthButton(type: .system)
        button.backgroundColor = #colorLiteral(red: 0.9294117647, green: 0.5294117647, blue: 0.4745098039, alpha: 1)
        button.tintColor = .white
        button.setImage(#imageLiteral(resourceName: "comment"), for: .normal)
        button.imageView?.setDimensions(height: 30, width: 30)
        button.addTarget(self, action: #selector(handleNewMessage), for: .touchUpInside)
        return button
    }()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureNavigationBar()
        configureTableView()
        configureUI()
        fetchConversations()
        
    }
    
    // MARK: - Helpers
    
    func configureUI() {
        
        view.addSubview(newMessageButton)
        newMessageButton.setDimensions(height: 56, width: 56)
        newMessageButton.layer.cornerRadius = 56 / 2
        newMessageButton.anchor(bottom: view.safeAreaLayoutGuide.bottomAnchor, right: view.rightAnchor, paddingBottom: 16, paddingRight: 24,width: 56,height: 56)
    }
    
    func configureNavigationBar() {
        
        let attributes = [NSAttributedString.Key.font: UIFont(name: "Marker Felt", size: 23)!]
        UINavigationBar.appearance().titleTextAttributes = attributes
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: #imageLiteral(resourceName: "cancel_shadow"), style: .plain, target: self, action: #selector(handleDismis))
        self.navigationItem.rightBarButtonItem?.tintColor = .black
        
        self.navigationItem.title = "^-^ Friends ^-^"
        
    }
    
    func configureTableView() {
        
        tableView.register(ConversationCell.self, forCellReuseIdentifier: reuseIndentifier)
        tableView.backgroundColor = .white
        tableView.rowHeight = 80
        
        tableView.separatorStyle = .none
        headerView.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: 200)
        tableView.tableHeaderView = headerView
        
        tableView.tableFooterView = UIView(frame: .init(x: 0, y: 0, width:  view.frame.width, height: 50))
        
        tableView.delegate = self
        tableView.dataSource = self
        
        view.addSubview(tableView)
        tableView.frame = view.frame
        
    }
    
    func showChatController(forUser user:User) {
        let chatController = ChatController(user: user)
        navigationController?.pushViewController(chatController, animated: true)
    }
    
    // MARK: - Actions
    
    @objc func handleDismis() {
        dismiss(animated: true, completion: nil)
    }
    
    @objc func handleNewMessage() {
        
        let newController = NewMessageController()
        newController.delegate = self
        let nav = UINavigationController(rootViewController: newController)
        nav.modalPresentationStyle = .fullScreen
        present(nav, animated: true, completion: nil)
    }
    
    // MARK: - API
    
    func fetchConversations() {
        
        FetchDatabase.fetchConversations { conversation in
         
            conversation.forEach { (conversation) in
                let message = conversation.message
                self.conversationsDic[message.chatPartnerId] = conversation
            }
            
            self.conversations = Array(self.conversationsDic.values)
            
            self.tableView.reloadData()
        }
    }
    
}

// MARK: - MessageHeaderDelegate

extension ConversationsController:MessageHeaderDelegate {
    func messageHeader(_ header: MessageHead, wantToStartChartWith uid: String) {
        print("MessageHeaderDelegate")
    }
}


// MARK: - UITableViewDataSource

extension ConversationsController:UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return conversations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIndentifier, for: indexPath) as! ConversationCell
        cell.conversation = conversations[indexPath.row]
        
        return cell
    }
}

// MARK: - UITableViewDelegate

extension ConversationsController:UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let user = conversations[indexPath.row].user
        showChatController(forUser: user)
    }
}

// MARK: - NewMessageControllerDelegate

extension ConversationsController:NewMessageControllerDelegate {
    func controller(_ controller: NewMessageController, wantToStartChatWith user: User) {
        controller.dismiss(animated: true, completion: nil)
        showChatController(forUser: user)
        
    }
}

// MARK: - MessageCellDelegate

extension ConversationsController:MessageCellDelegate {
    
    func configureUserData(for cell: ConversationCell) {
        
//        guard let chatParnerId = cell.conversation?.message.getChatPartnerId() else { return }
//        FetchDatabase.fetchUserWithUid(with: chatParnerId) { (users) in
//
//            cell.profileImageView.loadImage(with: users.profileImageUrl)
//            cell.usernameLabel.text = users.username
//
//            print("MessageCellDelegate: message \(users.username)")
//        }
//
    }
    
}



