//
//  SearchController.swift
//  Travel
//
//  Created by AOM on 7/20/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit
import Firebase

private let reuseIdentifier = "SearchCell"

class SearchController: UITableViewController,UISearchBarDelegate {
    
    // MARK: - Properties
    
   private var users = [User]()
    var filteredUsers = [User]()
    var searchBar = UISearchBar()
    var inSearchMode = false
    
        var userProfileController: ProfileController?
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        configureSearchBar()
        
        configureTableview()
        
        fetchUser()
        
    }
    
    func fetchUser() {
        
        showLoader(true)
        
        FetchDatabase.fetchAllUser(completion: {(user) in
            self.users.append(contentsOf: user)
            self.tableView.reloadData()
            self.showLoader(false)
        })
    }
    
    func configureSearchBar() {
        searchBar.sizeToFit()
        searchBar.delegate = self
        navigationItem.titleView = searchBar
        searchBar.barTintColor = .lightGray
        searchBar.tintColor = .black
    }
    
    func configureTableview() {
        
        // register cell class
        tableView.register(UserCell.self, forCellReuseIdentifier: reuseIdentifier)
        
        // separator insets
        tableView.separatorInset = UIEdgeInsets(top: 20, left: 65, bottom: 0, right: 0)
    }
    
    // show cancel searchbar
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        
        searchBar.showsCancelButton = true
        
        tableView.separatorColor = .lightGray
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        //        let searchText = searchText.lowercased()
        
        if searchText.isEmpty || searchText == "" {
            inSearchMode = false
            tableView.reloadData()
        }else {
            inSearchMode = true
            filteredUsers = users.filter({(user) -> Bool in
                return user.username.contains(searchText)
            })
            tableView.reloadData()
        }
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
        searchBar.showsCancelButton = false
        searchBar.text = nil
        inSearchMode = false
        
        tableView.separatorColor = .clear
        tableView.reloadData()
        
    }
}

// MARK: - Table view data source

extension SearchController {
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if inSearchMode {
            return filteredUsers.count
        }else {
            return users.count
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! UserCell
        
        if inSearchMode {
            let viewModelFilter = UserViewModel(user: filteredUsers[indexPath.row])
            cell.viewModel = viewModelFilter
        }else{
            let viewModel = UserViewModel(user: users[indexPath.row])
            cell.viewModel = viewModel
        }
        return cell
    }
}

// MARK: - Table view delegate

extension SearchController {
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        var user:User!
        if inSearchMode {
            user = filteredUsers[indexPath.row]
        }else {
            user = users[indexPath.row]
        }
        
        // create instance of user profile vc
        let userPorfileVC = ProfileController(collectionViewLayout: UICollectionViewFlowLayout())
        userPorfileVC.user = user
        userPorfileVC.backButton.isHidden = false
        
        userPorfileVC.modalTransitionStyle   = .crossDissolve;
        userPorfileVC.modalPresentationStyle = .overCurrentContext

        self.present(userPorfileVC, animated: true, completion: nil)
        
        
    }
}
