//
//  NotificationController.swift
//  Travel
//
//  Created by AOM on 7/18/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit
import Firebase

private let reuseIdentifer = "NotificationCell"

class NotificationController: UITableViewController {
    
    // MARK: - Propertices
    
    var timer: Timer?
    var notifications = [Notification]()
    var refresher = UIRefreshControl()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureUI()
        
        // fetch notifications
        fetchNotifications()
        
        // refresh control
        configureRefreshControl()
        
    }
    
    // MARK : Helpers
    
    func configureUI() {
        
        let attributes = [NSAttributedString.Key.font: UIFont(name: "Marker Felt", size: 23)!]
        UINavigationBar.appearance().titleTextAttributes = attributes
        
        self.navigationItem.title = "^-^ Notification ^-^"
        
        tableView.register(NotificationCell.self, forCellReuseIdentifier: reuseIdentifer)
        
    }
    
    func configureRefreshControl() {
        refresher.addTarget(self, action: #selector(handleRefresh), for: .valueChanged)
        self.tableView.refreshControl = refresher
    }
    
    // MARK: - Handlers
    
    @objc func handleRefresh() {
        self.notifications.removeAll()
        self.tableView.reloadData()
        fetchNotifications()
        refresher.endRefreshing()
    }
    
    @objc func handleSortNotifications() {
        self.notifications.sort { (notification1, notification2) -> Bool in
            return notification1.creationDate > notification2.creationDate
        }
        self.tableView.reloadData()
    }
    
    func handleReloadTable() {
        self.timer?.invalidate()
        
        self.timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(handleSortNotifications), userInfo: nil, repeats: false)
    }
    
    func getCommentData(forNotification notification:Notification) {
        
        guard let postId = notification.postId else { return }
        guard let commentId = notification.commentId else { return }
        
        COLLECTION_COMMENT.document(postId).getDocument { (snapshot, error) in
            
            snapshot?.data()?.forEach({ (key,value) in
                if key == commentId {
                    let dictionary = value as! Dictionary<String,Any>
                    guard let commentText = dictionary["commentText"] else { return }
                    notification.commentText = commentText as! String
                }
            })
        }
        
    }
    
    func fetchNotifications() {
        
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_NOTIFICATIONS.document(currentUid).getDocument { (snapshot, _) in
            
            snapshot?.data()?.forEach({ (key, value) in
                
                let notificationId = key
                let dictionary = value as? Dictionary<String, Any>
                
                print("fetchNotifications \(dictionary)" )
                
                guard let uid = dictionary!["uid"] as? String else { return }
                
                print("fetchNotifications uid \(uid)" )
                
                FetchDatabase.fetchUserWithUid(with: uid) { (user) in
                    
                    if let postId = dictionary!["postId"] as? String {
                        
                        print("fetchNotifications postId \(postId)" )
                        
                        FetchDatabase.fetchPost(postId: postId) { (post) in
                            
                            let notification = Notification(user: user, post: post, dictionary: dictionary!)
                            
                            if notification.notificationType  == .Comment {
                                self.getCommentData(forNotification: notification)
                            }
                            self.notifications.append(notification)
                            self.handleReloadTable()
                            
                            print("fetchNotifications notification \(notification)" )
                        }
                    } else {
                        let notification = Notification(user: user, dictionary: dictionary!)
                        self.notifications.append(notification)
                        self.handleReloadTable()
                        
                        print("fetchNotifications notification else \(notification)" )
                    }
                }
                
                COLLECTION_NOTIFICATIONS.document(currentUid).setData([notificationId : ["checked":1]],merge: true)
                
            })
            
        }
        
    }
}

// MARK: - Table view data source

extension NotificationController:NotificationCellDelegate {
    func handleFollowTapped(for cell: NotificationCell) {
        
        guard let user = cell.notification?.user else { return }
        
        if user.isFollowed {
            
            // handle unfollow user
            user.unfollow()
            cell.followButton.configure(didFollow: false)
        } else {
            
            // handle follow user
            user.follow()
            cell.followButton.configure(didFollow: true)
        }
        
    }
    
    func handlePostTapped(for cell: NotificationCell) {
        
        guard let post = cell.notification?.post else { return }
        guard let notification = cell.notification else { return }
        
        if notification.notificationType == .Comment {
            let commentController = CommentController(collectionViewLayout: UICollectionViewFlowLayout())
            commentController.post = post
            navigationController?.pushViewController(commentController, animated: true)
        } else {
            let feedController = FeedController(collectionViewLayout: UICollectionViewFlowLayout())
            //            feedController.viewSinglePost = true
            feedController.post = post
            navigationController?.pushViewController(feedController, animated: true)
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        print("notifications.count \(notifications.count)")
        return notifications.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifer, for: indexPath) as! NotificationCell
        print("notifications cell \(notifications)")
        
        let notification = notifications[indexPath.row]
        cell.notification = notification
        
        if notification.notificationType == .Comment {
            if let commentText = notification.commentText {
                cell.configureNotificationLabel(withCommentText: commentText)
            }
        }
        
        cell.delegate = self
        
        return cell
    }
}
