//
//  MainTabController.swift
//  Travel
//
//  Created by AOM on 7/16/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

class MainTabController: UITabBarController,UITabBarControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.delegate = self
        configureViewControllers()
    }
    
    func constructNavController(unselectedImage:UIImage,selectedImage:UIImage,rootViewController:UIViewController =
        UIViewController())-> UINavigationController  {
        
        // construct nav controller
        let navController = UINavigationController(rootViewController: rootViewController)
        navController.tabBarItem.image = unselectedImage
        navController.tabBarItem.selectedImage = selectedImage
        navController.navigationBar.tintColor = .systemPink
      
        return navController
    }
    
    func configureViewControllers() {
        
        // home feed controller
        let feedVC = constructNavController(unselectedImage: #imageLiteral(resourceName: "home_unselected"), selectedImage: #imageLiteral(resourceName: "home_selected"), rootViewController: FeedController(collectionViewLayout: UICollectionViewFlowLayout()))
        
        // search feed controller
         let searchVC = constructNavController(unselectedImage: #imageLiteral(resourceName: "search_selected"), selectedImage: #imageLiteral(resourceName: "search_selected"),rootViewController:
                         SearchController())
      
        // select image controller
        let selectImageVC = constructNavController(unselectedImage: #imageLiteral(resourceName: "plus_unselected-2"), selectedImage: #imageLiteral(resourceName: "plus_unselected-2"))
        
        let notificationVC = constructNavController(unselectedImage: #imageLiteral(resourceName: "like_unselected"), selectedImage: #imageLiteral(resourceName: "like_selected"),rootViewController: NotificationController())
        
        let profileVC = constructNavController(unselectedImage: #imageLiteral(resourceName: "profile_unselected"), selectedImage: #imageLiteral(resourceName: "profile_selected"),rootViewController:
            ProfileController(collectionViewLayout: UICollectionViewFlowLayout()))
        
        viewControllers = [feedVC,searchVC,selectImageVC,notificationVC,profileVC]
        //
        //   tab bar tint color
        tabBar.tintColor = #colorLiteral(red: 0.8155518174, green: 0.5029943585, blue: 0.4398008883, alpha: 1)
        
    }
    
    // MARK: - UITabBar
    
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        
        let index = viewControllers?.firstIndex(of: viewController)
   
        if index == 2 {
            
            let selectImageVC = SelecteImageController(collectionViewLayout: UICollectionViewFlowLayout())
            let navController = UINavigationController(rootViewController: selectImageVC)
            navController.modalPresentationStyle = .fullScreen
            navController.navigationBar.tintColor = .black
            present(navController, animated: true, completion: nil)
            
            return false
        }
        
        return true
        
    }
}
