//
//  ForgotPasswordController.swift
//  Travel
//
//  Created by AOM on 7/13/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

protocol ForgotPasswordControllerDelegate:class {
    func didSendForgotPasswordLink()
}

class ForgotPasswordController: UIViewController {
    
    //  MARK : Properties
    
    private var viewModel = TextViewModel()
    weak var delegate:ForgotPasswordControllerDelegate?
    var email:String?
    
    private let backButton: NavigationButton = {
        let button = NavigationButton(type: .system)
        button.addTarget(self, action: #selector(handleDismissal), for: .touchUpInside)
        return button
    }()
    
    private let titleLabel = CustomTitleLabel(attributedTitle: "Forgot Password", fontSize: 30, attributed: "Enter your email \("\n")to reset the password", numberOfLine: 3)
    
    private let emailTextField = CustomTextField(placeholder: "Email",image: #imageLiteral(resourceName: "ic_mail_outline_white"))
    
    private let resetButton:AuthButton = {
        let button = AuthButton(type: .system)
        button.title = "Reset Password"
        button.isEnabled = false
        button.setTitleColor(UIColor(white: 1, alpha: 0.5), for: .normal)
        button.backgroundColor = #colorLiteral(red: 0.9405841231, green: 0.5281627774, blue: 0.4746308327, alpha: 1)
        button.addTarget(self, action: #selector(handleResetPassword), for: .touchUpInside)
        return button
    }()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureUI()
        configureNotificationObservers()
        loadEmail()
        
    }
    
    // MARK : Helpers
    
    func configureUI() {
        
        configureGradientBackground()
        
        navigationController?.navigationBar.isHidden = true
        navigationController?.navigationBar.barStyle = .black
        
        view.addSubview(backButton)
        backButton.anchor(top: view.safeAreaLayoutGuide.topAnchor, left: view.leftAnchor, paddingTop: 16, paddingLeft: 16)
        
        view.addSubview(titleLabel)
        titleLabel.centerX(inView: view)
        titleLabel.anchor(top:view.safeAreaLayoutGuide.topAnchor,paddingTop: 80)
        
        let stackView = UIStackView(arrangedSubviews: [emailTextField,resetButton])
        stackView.axis = .vertical
        stackView.spacing = 16
        
        view.addSubview(stackView)
        
        stackView.anchor(top: titleLabel.bottomAnchor, left: view.leftAnchor, right: view.rightAnchor, paddingTop: 50, paddingLeft: 40, paddingRight: 40)
        
    }
    
    func loadEmail(){
        
        guard let email = email else {return}
        viewModel.inputText = email
        emailTextField.text = email
        
        updateForm()
    }
    
    func configureNotificationObservers() {
        
        emailTextField.addTarget(self, action: #selector(textDidChange), for: .editingChanged)
        
    }
    
    // MARK: - Handlers
    
    @objc func handleDismissal() {
        dismiss(animated: true, completion: nil)
    }
    
    @objc func textDidChange(_ sender:UITextField) {
        
        if sender == emailTextField {
            viewModel.inputText = sender.text
        }
        
        updateForm()
    }
    
    @objc func handleResetPassword() {
        
        guard let email = viewModel.inputText else {return}
        self.showLoader(true)
        
        AuthService.resetPassword(forEmail: email) { error in
            self.showLoader(false)
            if let error = error {
                self.showMessage(withTitle: "Error", message: error.localizedDescription)
                return
            }
            self.delegate?.didSendForgotPasswordLink()
        }
        // go to Login page
        
        
    }
}

// MARK: - FormViewModel

extension ForgotPasswordController:FormViewModel {
    func updateForm() {
        resetButton.isEnabled = viewModel.shouldEnableButton
        resetButton.setTitleColor(viewModel.buttonTitleColor, for: .normal)
        
    }
}

