//
//  SignUpController.swift
//  Travel
//
//  Created by AOM on 7/12/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit
import FacebookCore
import FacebookLogin
import GoogleSignIn
import Firebase
import FirebaseAuth

class SignUpController: UIViewController {
    
    //  MARK : Properties
    
    private var viewModel = SignUpViewModel()
    weak var delegate:AuthenticationDelegate?
    
    private let titleLabel = CustomTitleLabel(attributedTitle: "Create Account",fontSize: 30)
    
    private let backButton: NavigationButton = {
        let button = NavigationButton(type: .system)
        button.addTarget(self, action: #selector(handleDismissal), for: .touchUpInside)
        return button
    }()
    
    private let userTextField = CustomTextField(placeholder: "Username" , image: #imageLiteral(resourceName: "ic_person_outline_white"))
    private let emailTextField = CustomTextField(placeholder: "Email" , image: #imageLiteral(resourceName: "ic_mail_outline_white"))
    private let passwordTextField = CustomTextField(placeholder: "Password",image: #imageLiteral(resourceName: "ic_lock_outline_white"),isSecureField:true)
    
    private lazy var signUpButton:AuthButton = {
        let button = AuthButton(type: .system)
        button.title = "Sign Up"
        button.backgroundColor = #colorLiteral(red: 0.9405841231, green: 0.5281627774, blue: 0.4746308327, alpha: 1)
        button.isEnabled = false
        button.setTitleColor(UIColor(white: 1, alpha: 0.5), for: .normal)
        button.addTarget(self, action: #selector(handleSignUp), for: .touchUpInside)
        
        return button
    }()
    
    private let dividerView = Dividerview()
    
    private let facebookButton:AuthButton = {
        let button = AuthButton(type: .system)
        button.title = " Facebook"
        button.backgroundColor = .white
        button.setImage(#imageLiteral(resourceName: "facebook").withRenderingMode(.alwaysOriginal), for: .normal)
        button.setTitleColor(UIColor(white: 1, alpha: 0.5), for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.addTarget(self, action: #selector(handleFacebook), for: .touchUpInside)
        
        return button
    }()
    
    private lazy var googleButton:AuthButton = {
        let button = AuthButton(type: .system)
        button.title = " Email"
        button.backgroundColor = #colorLiteral(red: 0.7848690152, green: 0.7801650167, blue: 0.8011476398, alpha: 1)
        button.setImage(#imageLiteral(resourceName: "ic_mail_outline_white").withRenderingMode(.alwaysOriginal), for: .normal)
        button.addTarget(self, action: #selector(handleLoginGoolgle), for: .touchUpInside)
        
        return button
    }()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureGoogleSignIn()
        configureUI()
    }
    
    @objc func textDidChange(_ sender:UITextField) {
        
        if sender == emailTextField {
            viewModel.email = sender.text
        }else if sender == userTextField {
            viewModel.username = sender.text
        }else {
            viewModel.password = sender.text
        }
        updateForm()
    }
    
    // MARK : Helpers
    
    func configureUI() {
        
        configureGradientBackground()
        configureNotificationObservers()
        
        navigationController?.navigationBar.isHidden = true
        navigationController?.navigationBar.barStyle = .black
        
        view.addSubview(backButton)
        backButton.anchor(top: view.safeAreaLayoutGuide.topAnchor, left: view.leftAnchor, paddingTop: 16, paddingLeft: 16)
        
        view.addSubview(titleLabel)
        titleLabel.centerX(inView: view)
        titleLabel.anchor(top:view.safeAreaLayoutGuide.topAnchor,paddingTop: 60)
        
        let stackView = UIStackView(arrangedSubviews: [userTextField,emailTextField,passwordTextField,signUpButton])
        stackView.axis = .vertical
        stackView.spacing = 16
        
        view.addSubview(stackView)
        stackView.anchor(top: titleLabel.bottomAnchor, left: view.leftAnchor, right: view.rightAnchor, paddingTop: 30, paddingLeft: 40, paddingRight: 40)
        
        let stackView2 = UIStackView(arrangedSubviews: [dividerView, facebookButton,googleButton])
        stackView2.axis = .vertical
        stackView2.spacing = 16
        
        view.addSubview(stackView2)
        stackView2.anchor(top: stackView.bottomAnchor, left: view.leftAnchor, right: view.rightAnchor, paddingTop: 40, paddingLeft: 40, paddingRight: 40)
        
    }
    
    func configureNotificationObservers() {
        emailTextField.addTarget(self, action: #selector(textDidChange), for: .editingChanged)
        userTextField.addTarget(self, action: #selector(textDidChange), for: .editingChanged)
        passwordTextField.addTarget(self, action: #selector(textDidChange), for: .editingChanged)
        
    }
    
    func configureGoogleSignIn() {
        GIDSignIn.sharedInstance()?.presentingViewController = self
        GIDSignIn.sharedInstance()?.delegate = self
    }
    
    // MARK: - Handlers
    
    @objc func handleDismissal() {
        dismiss(animated: true, completion: nil)
    }
    
    @objc func handleSignUp() {
        
        guard let email = emailTextField.text else { return  }
        guard let username = userTextField.text else { return  }
        guard let password = passwordTextField.text else { return  }
        
        self.showLoader(true)
        
        let credentials = AuthCredentials(email: email, password: password, username: username)
        
        AuthService.registerUser(withCredentials: credentials) { error in
            self.showLoader(false)
            if let error = error {
                self.showMessage(withTitle: "Error", message: error.localizedDescription)
                return
            }
            self.delegate?.authenticationComplete()
        }
    }
    
    @objc func handleFacebook() {
        
        self.showLoader(true)
        
        let loginManager = LoginManager()
        loginManager.logIn(permissions: [ .publicProfile, .email, .userPhotos], viewController: self) { loginResult in
            switch loginResult {
            case .failed(let error):
                print("debug error handle facebook \(error)")
            case .cancelled:
                print("debug cancel handle facebook")
            case .success(_, _, let accessToken):
                
                AuthService.signInWithFaceBook(accessToken: accessToken.tokenString) { error in
                    self.showLoader(false)
                    
                    if let error = error {
                        self.showMessage(withTitle: "Error", message: error.localizedDescription)
                        return
                    }
                    self.delegate?.authenticationComplete()
                }
                
                break
                
            }
        }
    }
    
    @objc func handleLoginGoolgle() {
        GIDSignIn.sharedInstance()?.signIn()
    }
    
    @objc func handleLogin() {
        let loginVC = LoginController()
        loginVC.modalPresentationStyle = .fullScreen
        present(loginVC, animated: true, completion: nil)
    }
    
}

// MARK: - FormViewModel

extension SignUpController:FormViewModel {
    func updateForm() {
        signUpButton.isEnabled = viewModel.shouldEnableButton
        signUpButton.setTitleColor(viewModel.buttonTitleColor, for: .normal)
    }
}

// MARK: - FacebookDelegate

extension SignUpController:LoginButtonDelegate {  // FBLoginButton
    func loginButton(_ loginButton: FBLoginButton, didCompleteWith result: LoginManagerLoginResult?, error: Error?) {
        print("didCompleteWith")
    }
    
    func loginButtonDidLogOut(_ loginButton: FBLoginButton) {
        print("loginButtonDidLogOut")
    }
}

// MARK: - GIDSignInDelegate

extension SignUpController:GIDSignInDelegate {
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error?) {
        self.showLoader(true)
        AuthService.signInWithGoogle(didSignIn: user) {(error) in
            self.showLoader(false)
            self.delegate?.authenticationComplete()
            
            print("debug handle google sign in")
        }
    }
    
}

