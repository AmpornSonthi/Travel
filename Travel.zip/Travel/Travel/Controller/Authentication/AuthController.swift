//
//  LoginController.swift
//  Travel
//
//  Created by AOM on 7/11/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit

class AuthController: UIViewController {
    
    //  MARK : Properties
    
    weak var delegate:AuthenticationDelegate?
    
    private let bgImage:UIImageView = {
        let bgImage = UIImageView(image: #imageLiteral(resourceName: "bg-2"))
        bgImage.contentMode = .scaleAspectFill
        return bgImage
    }()
    
    private let appLabel = CustomTitleLabel(attributedTitle: "^-^ Travel ^-^", fontSize: 45)
    private let titleLabel = CustomTitleLabel(attributedTitle: "Everywhere you go.", fontSize: 30)
    private let detailLabel = CustomTitleLabel(attributedTitle: "To share the travel experience.")
    
    private let loginButton:AuthButton = {
        let button = AuthButton(type: .system)
        button.title = "Log In"
        button.layer.borderColor = UIColor.white.cgColor
        button.addTarget(self, action: #selector(handleLoginPage), for: .touchUpInside)
        return button
    }()
    
    private lazy var signUpButton:AuthButton = {
        let button = AuthButton(type: .system)
        button.title = "Sign Up"
        button.backgroundColor = .white
        button.setTitleColor(.black, for: .normal)
        button.addTarget(self, action: #selector(handleSignUpPage), for: .touchUpInside)
        
        return button
    }()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureUI()
        
    }
    
    // MARK : Helpers
    
    func configureUI() {
        
        navigationController?.navigationBar.isHidden = true
        navigationController?.navigationBar.barStyle = .black
        
        configureGradientBackground()
        
        view.addSubview(bgImage)
        //        bgImage.setDimensions(height: 400, width: 400)
        bgImage.setHeight(height: 400)
        bgImage.anchor(top: view.topAnchor, left: view.safeAreaLayoutGuide.leftAnchor,right: view.safeAreaLayoutGuide.rightAnchor)
        
        let stackViewBtn = UIStackView(arrangedSubviews: [loginButton,signUpButton])
        stackViewBtn.axis = .horizontal
        stackViewBtn.spacing = 15
        stackViewBtn.distribution = .fillEqually
        
        view.addSubview(stackViewBtn)
        stackViewBtn.anchor(top: nil, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor,  paddingLeft: 35, paddingBottom: 40, paddingRight: 35)
        
        let stackViewLabel = UIStackView(arrangedSubviews: [appLabel
            ,titleLabel, detailLabel])
        stackViewLabel.axis = .vertical
        
        stackViewLabel.setHeight(height: 170)
        view.addSubview(stackViewLabel)
        
        stackViewLabel.centerX(inView: view)
        stackViewLabel.anchor( bottom: stackViewBtn.topAnchor, paddingBottom: 50)
        
    }
    
    // MARK: - Handlers
    
    @objc func handleLoginPage() {
        let loginVC = LoginController()
        loginVC.modalPresentationStyle = .fullScreen
        present(loginVC, animated: true, completion: nil)
    }
    
    @objc func handleSignUpPage() {
        let signUpVC = SignUpController()
          signUpVC.delegate = delegate
        signUpVC.modalPresentationStyle = .fullScreen
        present(signUpVC, animated: true, completion: nil)
    }
    
}
