//
//  LoginController.swift
//  Travel
//
//  Created by AOM on 7/12/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import UIKit
import Firebase

protocol AuthenticationDelegate:class {
    func authenticationComplete()
}

class LoginController: UIViewController {
    
    //  MARK : Properties
    
    private var viewModel = LoginViewModel()
    weak var delegate:AuthenticationDelegate?
    
    private let backButton: NavigationButton = {
        let button = NavigationButton(type: .system)
        button.addTarget(self, action: #selector(handleDismissal), for: .touchUpInside)
        return button
    }()
    
    private let titleLabel = CustomTitleLabel(attributedTitle: "Welcome back", fontSize: 30, attributed: "Log in withe your account", numberOfLine: 2)
    
    private let emailTextField = CustomTextField(placeholder: "Email",image: #imageLiteral(resourceName: "ic_mail_outline_white"))
    private let passwordTextField = CustomTextField(placeholder: "Password",image: #imageLiteral(resourceName: "ic_lock_outline_white"),isSecureField: true)
    
    private let loginButton:AuthButton = {
        let button = AuthButton(type: .system)
        button.title = "Log In"
        button.isEnabled = false
        button.setTitleColor(UIColor(white: 1, alpha: 0.5), for: .normal)
        button.backgroundColor = #colorLiteral(red: 0.9405841231, green: 0.5281627774, blue: 0.4746308327, alpha: 1)
        button.addTarget(self, action: #selector(handleLogin), for: .touchUpInside)
        return button
    }()
    
    private let forgotButton:CustomTitleButton = {
        let button = CustomTitleButton(attributed: "Forgot Password?" )
        button.addTarget(self, action: #selector(handleForgotPassword), for: .touchUpInside)
        
        return button
    }()
    
    private let dontHaveAccountButton:CustomTitleButton = {
        let button = CustomTitleButton(attributed: "Sign Up" , attributedTitle: "Don't have an account?  ")
        button.addTarget(self, action: #selector(handleSignUpPage), for: .touchUpInside)
        
        return button
    }()
    
    @objc func textDidChange(_ sender:UITextField) {
        if sender == emailTextField {
            viewModel.email = sender.text
        }else {
            viewModel.password = sender.text
        }
        
        print("DEBUG: Form is valid \(viewModel.formIsValid)")
        updateForm()
    }
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureUI()
        
    }
    
    // MARK : Helpers
    
    func configureUI() {
        
        configureGradientBackground()
        configureNotificationObservers()
        
        navigationController?.navigationBar.isHidden = true
        navigationController?.navigationBar.barStyle = .black
        
        view.addSubview(backButton)
        backButton.anchor(top: view.safeAreaLayoutGuide.topAnchor, left: view.leftAnchor, paddingTop: 16, paddingLeft: 16)
        
        view.addSubview(titleLabel)
        titleLabel.centerX(inView: view)
        titleLabel.anchor(top:view.safeAreaLayoutGuide.topAnchor,paddingTop: 80)
        
        let stackView = UIStackView(arrangedSubviews: [emailTextField,passwordTextField,loginButton])
        stackView.axis = .vertical
        stackView.spacing = 16
        
        view.addSubview(stackView)
        
        stackView.anchor(top: titleLabel.bottomAnchor, left: view.leftAnchor, right: view.rightAnchor, paddingTop: 50, paddingLeft: 40, paddingRight: 40)
        
        view.addSubview(forgotButton)
        forgotButton.anchor(top: stackView.bottomAnchor,paddingTop: 30)
        forgotButton.centerX(inView: view)
        
        view.addSubview(dontHaveAccountButton)
        dontHaveAccountButton.centerX(inView: view)
        dontHaveAccountButton.anchor(bottom: view.safeAreaLayoutGuide.bottomAnchor, paddingBottom: 16)
    }
    
    func configureNotificationObservers() {
        emailTextField.addTarget(self, action: #selector(textDidChange), for: .editingChanged)
        passwordTextField.addTarget(self, action: #selector(textDidChange), for: .editingChanged)
    }
    
    // MARK: - Handlers
    
    @objc func handleDismissal() {
        dismiss(animated: true, completion: nil)
        
    }
    
    @objc func handleLogin() {
        
        guard let email = emailTextField.text else { return }
        guard let password = passwordTextField.text else { return }
        
        self.showLoader(true)
        
        AuthService.logUserIn(withEmail: email, password: password) {( result,error) in
            self.showLoader(false)
            if let error = error {
                self.showMessage(withTitle: "Error", message: error.localizedDescription)
                return
            }
            self.delegate?.authenticationComplete()
        }
        
    }
    
    @objc func handleSignUpPage() {
        let signUpVC = SignUpController()
        signUpVC.modalPresentationStyle = .fullScreen
        signUpVC.delegate = delegate
        present(signUpVC, animated: true, completion: nil)
    }
    
    
    @objc func handleForgotPassword() {
        let forgotPasswordVC = ForgotPasswordController()
        forgotPasswordVC.email = emailTextField.text
        forgotPasswordVC.delegate = self
        forgotPasswordVC.modalPresentationStyle = .fullScreen
        present(forgotPasswordVC, animated: true, completion: nil)
    }
}

// MARK: - FormViewModel

extension LoginController:FormViewModel {
    func updateForm() {
        loginButton.isEnabled = viewModel.shouldEnableButton
        loginButton.setTitleColor(viewModel.buttonTitleColor, for: .normal)
    }
}

// MARK: - ForgotPasswordControllerDelegate

extension LoginController:ForgotPasswordControllerDelegate {
    func didSendForgotPasswordLink() {
        
        dismiss(animated: true, completion: nil)
        self.showMessage(withTitle: "Success", message: MSG_RESET_PASSWORD)
    }
    
}
