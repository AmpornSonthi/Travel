//
//  Post.swift
//  Travel
//
//  Created by AOM on 7/17/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import Foundation
import Firebase
import UIKit

class Post {
    
    let ownerUid:String
    var user:User?
    
    var caption:String!
    var likes:Int!
    let imageUrl:String
    var postId:String!
    var creationDate:Date!
    
    var didLike = false
    
    init(postId: String! , user: User, dictionary:[String:Any]) {
        
        self.postId = postId
        self.user = user
        
        self.caption = dictionary["caption"] as? String ?? ""
        
        self.likes = dictionary["likes"] as? Int ?? 0
        
        self.imageUrl = dictionary["imageUrl"] as? String ?? ""
        
        self.ownerUid = dictionary["ownerUid"] as? String ?? ""
        
        if let creationDate = dictionary["creationDate"] as? Double {
            self.creationDate = Date(timeIntervalSince1970: creationDate)
        }
    }
    
    func adjustLikes(addLike: Bool, completion: @escaping(Int) -> ()) {
        
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        guard let postId = self.postId else { return }
        
        print("adjustLikes \(self.postId)")
        print("adjustLikes postId \(postId)")
        
        if addLike {
            
            COLLECTION_USER_LIKE.document(currentUid).setData([postId: 1]) { (_) in
                
                self.sendLikeNotificationToServer()
                
                COLLECTION_POST_LIKE.document(self.postId).setData([currentUid: 1]) { (_) in
                    self.likes = self.likes + 1
                    self.didLike = true
                    
                    COLLECTION_POST.document(postId).updateData(["likes" : self.likes as Any]) {(error) in
                        
                        if let error = error {
                            print("error add likes \(error.localizedDescription)")
                            return
                        }
                    }
                    
                    completion(self.likes)
                    
                    print("add like \(self.likes)")
                }
            }
        } else {
            print("add like remove else \(postId)")
            COLLECTION_USER_LIKE.document(currentUid).getDocument { (snapshot, error) in
                
                snapshot?.data()?.forEach({ (key,value) in
                    
                    if postId == key {
                        
                        print("add like remove \(key) \(postId)")
                        
                        if let notificationID = value as? String {
                            
                            COLLECTION_NOTIFICATIONS.document(self.ownerUid).updateData([notificationID : FieldValue.delete()]) { (error) in
                                
                                self.removeLike { (likes) in
                                    print("add like remove if \(likes)")
                                    completion(likes)
                                }
                            }
                        } else {
                            self.removeLike { (likes) in
                                print("add like remove else \(likes)")
                                completion(likes)
                            }
                        }
                    }
                })
                
            }
        }
    }
    
    func removeLike(withCompletion completion: @escaping (Int) -> ()) {
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_USER_LIKE.document(currentUid).updateData([self.postId : FieldValue.delete()]) { (error) in
            if let error = error {
                print("Error removeLike \(error)")
            } else {
                print("delete successfully removeLike")
                
                COLLECTION_POST_LIKE.document(self.postId).updateData([currentUid :FieldValue.delete()]) { (error) in
                    
                    guard self.likes > 0 else { return }
                    self.likes = self.likes - 1
                    self.didLike = false
                    
                    COLLECTION_POST.document(self.postId).updateData(["likes" : self.likes as Any]) {(error) in
                        
                        if let error = error {
                            print("error remove likes \(error.localizedDescription)")
                            return
                        }
                    }
                    
                    completion(self.likes)
                    
                }
            }
        }
    }
    
    // like another user
    func sendLikeNotificationToServer() {
        
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        let creationDate = Int(NSDate().timeIntervalSince1970)
        
             print("COLLECTION_NOTIFICATIONS currentUid \(currentUid)")
         print("COLLECTION_NOTIFICATIONS ownerUid \(self.ownerUid )")
         print("COLLECTION_NOTIFICATIONS postId \(postId)")
        
        if currentUid != self.ownerUid {
            
            let values = ["checked": 0,
                          "creationDate": creationDate,
                          "uid": currentUid,
                          "type": LIKE_INT_VALUE,
                          "postId": postId!] as [String : Any]
           
            
            UploadDatabase.autoGenerateID { (id) in
                
                COLLECTION_NOTIFICATIONS.document(self.ownerUid).setData([id : values],merge: true) { (err) in
                    
                }
            }
        }
    }
    
}
