//
//  User.swift
//  Travel
//
//  Created by AOM on 7/11/20.
//  Copyright © 2020 AOM. All rights reserved.
//

import Firebase
import FirebaseCore
import FirebaseFirestoreSwift
import Foundation

class User {
    
    var uid:String!
    let email:String
    var username:String!
    var profileImageUrl:String!
    var isFollowed = false
    
    init(uid:String,dictionary:[String:Any]) {
        
        self.uid = uid
        self.email = dictionary["email"] as? String ?? ""
        self.username = dictionary["username"] as? String ?? ""
        self.profileImageUrl = dictionary["profileImageUrl"]  as? String ?? ""
    }
    
    init(dictionary:[String:Any]) {
        
        self.uid = dictionary["uid"] as? String ?? ""
        self.email = dictionary["email"] as? String ?? ""
        self.username = dictionary["username"] as? String ?? ""
        self.profileImageUrl = dictionary["profileImageUrl"]  as? String ?? ""
    }
    
    
    // add user-followers , user-following
    func follow() {
        
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        // UPDATE: - get uid like this to work with update
        guard let uid = uid else { return }
        
        // set is followed to true
        self.isFollowed = true
        
        let values = ["isFollowed": self.isFollowed] as [String : Any]
        
        // add followed user to current user-following structure
        COLLECTION_USER_FOLLOWING.document(currentUid).setData([uid:values],merge: true)
        
        // add current user to followed user-follower structure
        COLLECTION_USER_FOLLOWER.document(uid).setData([currentUid:1] ,merge: true)
        
        print("follow currentUid \(currentUid)")
        print("follow uid \(uid)")
        
        // upload follow notification to server
        uploadFollowNotificationToServer()
        
        //        // add followed users posts to current user-feed
        COLLECTION_USER_POST.document(uid).getDocument { (snpshot, _) in
            
            snpshot?.data()?.forEach({ (key,value) in
                COLLECTION_USER_FEED.document(currentUid).setData([key:1],merge: true)
            })
        }
    }
    
    // remove user-followers , user-following : firebase
    func unfollow() {
        
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        // set is followed to false
        self.isFollowed = false
        
        // UPDATE: - get uid like this to work with update
        guard let uid = uid else { return }
        
        self.isFollowed = false
        //
        COLLECTION_USER_FOLLOWING.document(currentUid).updateData([
            uid: FieldValue.delete(),
        ]) { err in
            if let err = err {
                print("Error updating unfollow: \(err)")
            } else {
                print("delete successfully unfollow")
            }
        }
        
        COLLECTION_USER_FOLLOWER.document(uid).updateData([
            currentUid: FieldValue.delete(),
        ]) { err in
            if let err = err {
                print("Error updating unfollow: \(err)")
            } else {
                print("delete successfully unfollow")
            }
        }
        
        COLLECTION_USER_POST.document(uid).addSnapshotListener  { (snpshot, _) in
            
            snpshot?.data()?.forEach({ (key,value) in
                COLLECTION_USER_FEED.document(currentUid).updateData([key : FieldValue.delete()]) { (error) in
                    print("unfollow fee \(key)")
                }
                
            })
        }
        
    }
    
    func checkIfUserIsFollowed(completion: @escaping(Bool) ->()) {
        
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
       
        var keys = ""
        
        COLLECTION_USER_FOLLOWING.document(currentUid).getDocument { (snap, _) in
            
            snap?.data()?.forEach({ (key,value) in
                
                if self.uid == key {
                    keys = key
                }
            })
            if self.uid == keys {
                self.isFollowed = true
                completion(true)
            }
            else {
                self.isFollowed = false
                completion(false)
            }
        }
    }
    
    // add firebase data *** notifications
    func uploadFollowNotificationToServer() {
        
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        let creationDate = Int(NSDate().timeIntervalSince1970)
        
        let values = ["checked": 0,
                      "creationDate": creationDate,
                      "uid": currentUid,
                      "type": FOLLOW_INT_VALUE] as [String : Any]
        
        UploadDatabase.autoGenerateID { (id) in
            COLLECTION_NOTIFICATIONS.document(self.uid).setData([id : values],merge: false)
        }
    }
    
}
